use std::io;
use rand::Rng;

const MIN: u8 = 1;
const MAX: u8 = 100;

fn gerar_numero_aleatorio() -> u8 {
    rand::thread_rng().gen_range(MIN..=MAX)
}

fn obter_palpite() -> Option<u8> {
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    input.trim().parse::<u8>().ok()
}

pub(crate) fn main() {
    let numero_secreto = gerar_numero_aleatorio();
    println!("Tente adivinhar o número entre {MIN} e {MAX}!");

    loop {
        match obter_palpite() {
            Some(palpite) if palpite == numero_secreto => {
                println!("🎉 Sucesso! Você acertou!");
                break;
            }
            Some(palpite) if palpite < numero_secreto => {
                println!("O número é maior! Tente novamente.");
            }
            Some(_) => {
                println!("O número é menor! Tente novamente.");
            }
            None => {
                println!("Por favor, insira um número válido!");
            }
        }
    }
}
/*

/*fn main() {
    todo!("Implementar um jogo de adivinhar onde o jogador tenta adivinhar um número aleatório decidido pelo computador")
}*/

use std::io;
use rand::Rng;

pub(crate) fn main() {
    let mut rng = rand::thread_rng();
    let random_num: u32 = rng.gen_range(1..=100); // Gera um número aleatório entre 1 e 100
    println!("Tente adivinhar o número entre 1 e 100!");

    loop {
        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap(); // Lê a entrada do usuário

        let parsed_num: u32 = match input.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Por favor, insira um número válido!");
                continue;
            }
        };

        if parsed_num == random_num {
            println!("🎉 Sucesso! Você acertou!");
            break;
        } else if parsed_num < random_num {
            println!("O número é maior! Tente novamente.");
        } else {
            println!("O número é menor! Tente novamente.");
        }
    }
*/