use num_bigint::BigUint;
use num_traits::{One, Zero};

/// Gera os primeiros `n` números da sequência de Fibonacci usando `BigUint`.
/// Para o `n` atualmente definido o tempo de execucao e de cerca de 2 minutos
fn fibonacci_up_to(n: usize) -> Vec<BigUint> {
    let mut sequence: Vec<BigUint> = Vec::new();

    // Inicializa os dois primeiros números da sequência de Fibonacci
    let (mut a, mut b) = (BigUint::zero(), BigUint::one());

    for _ in 0..n {
        sequence.push(a.clone());
        let next = a + &b;
        a = b;
        b = next;
    }

    sequence
}

fn main() {
    let n = 20001; // Defina até quantos números da sequência você quer calcular.

    // Gera a sequência de Fibonacci até `n`.
    let sequence = fibonacci_up_to(n);

    // Exibe Fibonacci em ordem crescente.
    println!("Sequência de Fibonacci em ordem crescente:");
    for (i, value) in sequence.iter().enumerate() {
        println!("fibonacci({}) = {}", i, value);
    }

    // Exibe Fibonacci em ordem decrescente.
    println!("\nSequência de Fibonacci em ordem decrescente:");
    for (i, value) in sequence.iter().enumerate().rev() {
        println!("fibonacci({}) = {}", n - i - 1, value);
    }
}


/*
/// Gera um iterador infinito da sequência de Fibonacci usando `BigUint`.
fn fibonacci_sequence() -> impl Iterator<Item = BigUint> {
    std::iter::successors(Some((BigUint::zero(), BigUint::one())), |(previous, next)| {
        Some((next.clone(), previous + next))
    })
        .map(|(previous, _)| previous) // Retorna apenas os números da sequência.
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_bigint::ToBigUint;

    #[test]
    fn test_fibonacci() {
        let mut fib_iter = fibonacci_sequence();
        let expected = vec![
            0u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            2u32.to_biguint().unwrap(),
            3u32.to_biguint().unwrap(),
            5u32.to_biguint().unwrap(),
            8u32.to_biguint().unwrap(),
            13u32.to_biguint().unwrap(),
        ];
        for value in &expected {
            assert_eq!(fib_iter.next(), Some(value.clone()));
        }
    }
}

fn main() {
    // Calcula e imprime os 1000 primeiros números da sequência de Fibonacci.
    for (i, value) in fibonacci_sequence().enumerate().take(10000) {
        println!("fibonacci({}) = {}", i, value);
    }
}
*/

/*use num_bigint::BigUint;
use num_traits::{One, Zero};

/// Constante contendo os números iniciais da sequência de Fibonacci.
const INITIAL_NUMBERS: (BigUint, BigUint) = (BigUint::zero(), BigUint::one());

/// Gera um iterador infinito da sequência de Fibonacci usando `BigUint`.
fn fibonacci_sequence() -> impl Iterator<Item = BigUint> {
    std::iter::successors(Some(INITIAL_NUMBERS), |(previous, next)| {
        Some((next.clone(), previous + next))
    })
        .map(|(previous, _)| previous) // Retorna apenas os números da sequência.
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_bigint::ToBigUint;

    #[test]
    fn test_fibonacci() {
        let mut fib_iter = fibonacci_sequence();
        let expected = vec![
            0u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            2u32.to_biguint().unwrap(),
            3u32.to_biguint().unwrap(),
            5u32.to_biguint().unwrap(),
            8u32.to_biguint().unwrap(),
            13u32.to_biguint().unwrap(),
        ];
        for value in &expected {
            assert_eq!(fib_iter.next(), Some(value.clone()));
        }
    }
}

fn main() {
    // Calcula e imprime os 1000 primeiros números da sequência de Fibonacci.
    for (i, value) in fibonacci_sequence().enumerate().take(1000) {
        println!("fibonacci({}) = {}", i, value);
    }
}
*/
/*
use num_bigint::BigUint;
use num_traits::{One, Zero};

/// Gera um iterador infinito da sequência de Fibonacci usando `BigUint`.
fn fibonacci_sequence() -> impl Iterator<Item = BigUint> {
    std::iter::successors(Some((BigUint::zero(), BigUint::one())), |(current, next)| {
        Some((next.clone(), current + next))
    })
        .map(|(current, _)| current) // Retorna apenas os valores da sequência
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_traits::ToBigUint;

    #[test]
    fn test_fibonacci() {
        let mut fib_iter = fibonacci_sequence();
        let expected = [
            0u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            1u32.to_biguint().unwrap(),
            2u32.to_biguint().unwrap(),
            3u32.to_biguint().unwrap(),
            5u32.to_biguint().unwrap(),
            8u32.to_biguint().unwrap(),
            13u32.to_biguint().unwrap(),
        ];

        for value in &expected {
            assert_eq!(fib_iter.next(), Some(value.clone()));
        }
    }
}

fn main() {
    // Calcula os 1000 primeiros números da sequência de Fibonacci
    for (i, value) in fibonacci_sequence().enumerate().take(1000) {
        println!("fibonacci({}) = {}", i, value);
    }
}
*/
/*
///use std::collections::HashMap;
/// Gera um iterador infinito da sequência de Fibonacci.
fn fibonacci_sequence() -> impl Iterator<Item = u64> {
    std::iter::successors(Some((0, 1)), |(prev, curr)| {
        Some((*curr, prev + curr))
    })
        .map(|(prev, _)| prev)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fibonacci() {
        let mut fib_iter = fibonacci_sequence();
        let expected = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];

        for &value in &expected {
            assert_eq!(fib_iter.next(), Some(value));
        }
    }
}

fn main() {
    // Exemplo de uso: calcula os primeiros 20 números de Fibonacci
    for (i, value) in fibonacci_sequence().enumerate().take(2000000) {
        println!("fibonacci({}) = {}", i, value);
    }
}
*/
/*
fn fibonacci(n: u32) -> u32 {
    if n == 0 {
        return 0;
    }
    if n == 1 {
        return 1;
    }

    // Armazenar somente os dois últimos resultados
    let mut previous = 0;
    let mut current = 1;

    for _ in 2..=n {
        let next = previous + current;
        previous = current;
        current = next;
    }

    current
}

#[cfg(test)]
mod fibonacci_test {
    use super::*;

    #[test]
    fn test_fibonacci() {
        assert_eq!(fibonacci(0), 0);
        assert_eq!(fibonacci(1), 1);
        assert_eq!(fibonacci(2), 1);
        assert_eq!(fibonacci(3), 2);
        assert_eq!(fibonacci(4), 3);
        assert_eq!(fibonacci(5), 5);
        assert_eq!(fibonacci(6), 8);
        assert_eq!(fibonacci(7), 13);
        assert_eq!(fibonacci(8), 21);
        assert_eq!(fibonacci(9), 34);
        assert_eq!(fibonacci(10), 55);
    }
}

fn main() {
    for i in 0..=2300000 {
        println!("fibonacci({}) = {}", i, fibonacci(i));
    }
}*/

/*fn fibonacci(n: u32) -> u32 {
    if n == 0 {
        return 0;
    }
    if n == 1 {
        return 1;
    }

    let mut fib_results = vec![0, 1]; // Vetor para armazenar resultados

    for i in 2..=n as usize {
        let next_fib = fib_results[i - 1] + fib_results[i - 2];
        fib_results.push(next_fib);
    }

    fib_results[n as usize]
}

#[cfg(test)]
mod fibonacci_test {
    use super::*;

    #[test]
    fn test_fibonacci() {
        assert_eq!(fibonacci(0), 0);
        assert_eq!(fibonacci(1), 1);
        assert_eq!(fibonacci(2), 1);
        assert_eq!(fibonacci(3), 2);
        assert_eq!(fibonacci(4), 3);
        assert_eq!(fibonacci(5), 5);
        assert_eq!(fibonacci(6), 8);
        assert_eq!(fibonacci(7), 13);
        assert_eq!(fibonacci(8), 21);
        assert_eq!(fibonacci(9), 34);
        assert_eq!(fibonacci(10), 55);
    }
}

fn main() {
    for i in 0..=23 {
        println!("fibonacci({}) = {}", i, fibonacci(i));
    }
}
*/
/*
fn fibonacci(n: u32, cache: &mut HashMap<u32, u32>) -> u32 {
    if let Some(&result) = cache.get(&n) {
        return result;
    }

    let result = match n {
        0 => 0,
        1 => 1,
        _ => fibonacci(n - 1, cache) + fibonacci(n - 2, cache),
    };

    cache.insert(n, result);
    result
}

/// Wrapper simplificado para o cálculo de Fibonacci com memoization.
fn calculate_fibonacci(n: u32) -> u32 {
    let mut cache = HashMap::new();
    fibonacci(n, &mut cache)
}

#[cfg(test)]
mod fibonacci_test {
    use super::*;

    #[test]
    fn test_fibonacci() {
        assert_eq!(calculate_fibonacci(0), 0);
        assert_eq!(calculate_fibonacci(1), 1);
        assert_eq!(calculate_fibonacci(2), 1);
        assert_eq!(calculate_fibonacci(3), 2);
        assert_eq!(calculate_fibonacci(4), 3);
        assert_eq!(calculate_fibonacci(5), 5);
        assert_eq!(calculate_fibonacci(6), 8);
        assert_eq!(calculate_fibonacci(7), 13);
        assert_eq!(calculate_fibonacci(8), 21);
        assert_eq!(calculate_fibonacci(9), 34);
        assert_eq!(calculate_fibonacci(10), 55);
    }
}

fn main() {
    for i in 0..=23 {
        println!("fibonacci({}) = {}", i, calculate_fibonacci(i));
    }
}
*/

/*use std::collections::HashMap;

/*fn fibonacci(n: u32) -> u32 {
   /* todo!("Implementar fibonacci aqui")*/
    match n {
        0 => 0,
        1 => 1,
        _ => fibonacci(n - 1) + fibonacci(n - 2),
    }

}*/
fn fibonacci(n: u32, memo: &mut HashMap<u32, u32>) -> u32 {
    if let Some(&result) = memo.get(&n) {
        return result;
    }

    let result = match n {
        0 => 0,
        1 => 1,
        _ => fibonacci(n - 1, memo) + fibonacci(n - 2, memo),
    };

    memo.insert(n, result);
    result
}

#[cfg(test)]
mod fibonacci_test {
    use super::*;
    use std::collections::HashMap;

    #[test]
    fn test_fibonacci() {
        assert_eq!(super::fibonacci(0, &mut Default::default()), 0);
        assert_eq!(super::fibonacci(1, &mut Default::default()), 1);
        assert_eq!(super::fibonacci(2, &mut Default::default()), 1);
        assert_eq!(super::fibonacci(3, &mut Default::default()), 2);
        assert_eq!(super::fibonacci(4, &mut Default::default()), 3);
        assert_eq!(super::fibonacci(5, &mut Default::default()), 5);
        assert_eq!(super::fibonacci(6, &mut Default::default()), 8);
        assert_eq!(super::fibonacci(7, &mut Default::default()), 13);
        assert_eq!(super::fibonacci(8, &mut Default::default()), 21);
        assert_eq!(super::fibonacci(9, &mut Default::default()), 34);
        assert_eq!(super::fibonacci(10, &mut Default::default()), 55);
    }

}

fn main() {

  /*  for i in 0..=23 {
        println!("fibonacci({}) = {}", i, fibonacci(i));
    }*/

    let mut memo = HashMap::new();

    for i in 0..=23 {
        println!("fibonacci({}) = {}", i, fibonacci(i, &mut memo));
    }

}
 */