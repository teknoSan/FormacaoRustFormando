/*use std::collections::{HashMap, HashSet};

// Define um trait para itens da biblioteca, com propriedades e métodos comuns.
trait LibraryItem: std::fmt::Debug {
    fn title(&self) -> &String;
    fn authors(&self) -> &Vec<String>;

    // Métodos adicionais com comportamentos específicos.
    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Err("Este tipo de item não possui dimensões.".to_string())
    }

    fn get_duration(&self) -> Result<u32, String> {
        Err("Este tipo de item não possui duração.".to_string())
    }
}

// Estrutura base: Livro
#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

impl LibraryItem for Book {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Audiobook
#[derive(Debug, Clone)]
struct AudioBook {
    title: String,
    authors: Vec<String>,
    duration: u32, // Em minutos
}

impl LibraryItem for AudioBook {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_duration(&self) -> Result<u32, String> {
        Ok(self.duration)
    }
}

// Estrutura: Estátua
#[derive(Debug, Clone)]
struct Statue {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64, f64), // Largura x Altura x Profundidade
}

impl LibraryItem for Statue {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Ok((self.dimensions.0, self.dimensions.1, Some(self.dimensions.2)))
    }
}

// Estrutura: Quadro
#[derive(Debug, Clone)]
struct Painting {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64), // Largura x Altura
}

impl LibraryItem for Painting {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Ok((self.dimensions.0, self.dimensions.1, None))
    }
}

// Biblioteca que suporta itens genéricos
struct Library {
    items: HashMap<String, Box<dyn LibraryItem>>, // Mapear ID/ISBN para itens genéricos.
    author_index: HashMap<String, HashSet<String>>, // Autor -> IDs
    title_index: HashMap<String, HashSet<String>>,  // Título -> IDs
}

impl Library {
    fn new() -> Self {
        Library {
            items: HashMap::new(),
            author_index: HashMap::new(),
            title_index: HashMap::new(),
        }
    }

    fn add_item(&mut self, id: String, item: Box<dyn LibraryItem>) {
        let authors = item.authors().clone();
        let title = item.title().clone();
        self.items.insert(id.clone(), item);

        // Indexar pelo autor.
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(id.clone());
        }

        // Indexar pelo título.
        self.title_index
            .entry(title)
            .or_insert_with(HashSet::new)
            .insert(id);
    }

    fn find_by_id(&self, id: &str) -> Option<&Box<dyn LibraryItem>> {
        self.items.get(id)
    }

    fn find_by_author(&self, author: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.author_index
            .get(author)
            .map_or(vec![], |ids| {
                ids.iter()
                    .filter_map(|id| self.items.get(id))
                    .collect()
            })
    }

    fn find_by_title(&self, title: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.title_index
            .get(title)
            .map_or(vec![], |ids| {
                ids.iter()
                    .filter_map(|id| self.items.get(id))
                    .collect()
            })
    }

    fn find_by_author_and_title(
        &self,
        author: &str,
        title: &str,
    ) -> Option<&Box<dyn LibraryItem>> {
        self.find_by_author(author)
            .into_iter()
            .find(|item| item.title() == title)
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_add_and_find_by_id() {
        let mut library = Library::new();
        library.add_item(
            "123".to_string(),
            Box::new(Book {
                title: "Rust Book".to_string(),
                authors: vec!["John Doe".to_string()],
                keywords: vec!["Rust".to_string()],
            }),
        );

        let book = library.find_by_id("123");
        assert!(book.is_some());
        assert_eq!(book.unwrap().title(), "Rust Book");
    }

    #[test]
    fn test_find_by_author() {
        let mut library = Library::new();
        library.add_item(
            "123".to_string(),
            Box::new(Book {
                title: "Rust Book".to_string(),
                authors: vec!["John Doe".to_string()],
                keywords: vec!["Rust".to_string()],
            }),
        );

        let results = library.find_by_author("John Doe");
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].title(), "Rust Book");
    }

    #[test]
    fn test_find_by_title() {
        let mut library = Library::new();
        library.add_item(
            "124".to_string(),
            Box::new(Book {
                title: "Rust Programming".to_string(),
                authors: vec!["Jane Doe".to_string()],
                keywords: vec!["Programming".to_string()],
            }),
        );

        let results = library.find_by_title("Rust Programming");
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].title(), "Rust Programming");
    }

    #[test]
    fn test_find_by_author_and_title() {
        let mut library = Library::new();
        library.add_item(
            "124".to_string(),
            Box::new(Book {
                title: "Rust Programming".to_string(),
                authors: vec!["Jane Doe".to_string()],
                keywords: vec!["Programming".to_string()],
            }),
        );

        let result = library.find_by_author_and_title("Jane Doe", "Rust Programming");
        assert!(result.is_some());
        assert_eq!(result.unwrap().title(), "Rust Programming");
    }

    #[test]
    fn test_get_dimensions() {
        let statue = Statue {
            title: "Statue of Liberty".to_string(),
            authors: vec!["Author X".to_string()],
            dimensions: (93.0, 305.0, 93.0),
        };
        let dimensions = statue.get_dimensions();
        assert!(dimensions.is_ok());
        let (width, height, depth) = dimensions.unwrap();
        assert_eq!(width, 93.0);
        assert_eq!(height, 305.0);
        assert_eq!(depth, Some(93.0));
    }

    #[test]
    fn test_get_duration() {
        let audiobook = AudioBook {
            title: "Rust Audio".to_string(),
            authors: vec!["Jane Doe".to_string()],
            duration: 120,
        };
        let duration = audiobook.get_duration();
        assert!(duration.is_ok());
        assert_eq!(duration.unwrap(), 120);
    }
}*/

use std::collections::{HashMap, HashSet};

// Define um trait para itens da biblioteca, com propriedades e métodos comuns
trait LibraryItem: std::fmt::Debug {
    fn title(&self) -> &String;
    fn authors(&self) -> &Vec<String>;

    // Métodos adicionais com comportamentos específicos
    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Err("Este tipo de item não possui dimensões.".to_string())
    }

    fn get_duration(&self) -> Result<u32, String> {
        Err("Este tipo de item não possui duração.".to_string())
    }
}

// Estruturas específicas
#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

impl LibraryItem for Book {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

#[derive(Debug, Clone)]
struct AudioBook {
    title: String,
    authors: Vec<String>,
    duration: u32, // Em minutos
}

impl LibraryItem for AudioBook {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_duration(&self) -> Result<u32, String> {
        Ok(self.duration)
    }
}

#[derive(Debug, Clone)]
struct Statue {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64, f64), // Largura x Altura x Profundidade
}

impl LibraryItem for Statue {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Ok((self.dimensions.0, self.dimensions.1, Some(self.dimensions.2)))
    }
}

#[derive(Debug, Clone)]
struct Painting {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64), // Largura x Altura
}

impl LibraryItem for Painting {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }

    fn get_dimensions(&self) -> Result<(f64, f64, Option<f64>), String> {
        Ok((self.dimensions.0, self.dimensions.1, None))
    }
}

struct Library {
    items: HashMap<String, Box<dyn LibraryItem>>, // Mapear ID/ISBN para itens genéricos.
    author_index: HashMap<String, HashSet<String>>, // Autor -> IDs
    title_index: HashMap<String, HashSet<String>>,  // Título -> IDs
}

impl Library {
    fn new() -> Self {
        Library {
            items: HashMap::new(),
            author_index: HashMap::new(),
            title_index: HashMap::new(),
        }
    }

    fn add_item(&mut self, id: String, item: Box<dyn LibraryItem>) {
        let authors = item.authors().clone();
        let title = item.title().clone();
        self.items.insert(id.clone(), item);

        // Indexar pelo autor
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(id.clone());
        }

        // Indexar pelo título
        self.title_index
            .entry(title)
            .or_insert_with(HashSet::new)
            .insert(id);
    }

    fn find_by_id(&self, id: &str) -> Option<&Box<dyn LibraryItem>> {
        self.items.get(id)
    }

    fn find_by_author(&self, author: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.author_index
            .get(author)
            .map_or(vec![], |ids| {
                ids.iter()
                    .filter_map(|id| self.items.get(id))
                    .collect()
            })
    }

    fn find_by_title(&self, title: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.title_index
            .get(title)
            .map_or(vec![], |ids| {
                ids.iter()
                    .filter_map(|id| self.items.get(id))
                    .collect()
            })
    }

    fn find_by_author_and_title(
        &self,
        author: &str,
        title: &str,
    ) -> Option<&Box<dyn LibraryItem>> {
        self.find_by_author(author)
            .into_iter()
            .find(|item| item.title() == title)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_on_invalid_get_dimensions() {
        let book = Book {
            title: "Rust Book".to_string(),
            authors: vec!["John Doe".to_string()],
            keywords: vec!["Rust".to_string()],
        };

        let error = book.get_dimensions().unwrap_err();
        assert_eq!(error, "Este tipo de item não possui dimensões.");
    }

    #[test]
    fn test_error_on_invalid_get_duration() {
        let statue = Statue {
            title: "Statue of Liberty".to_string(),
            authors: vec!["Author X".to_string()],
            dimensions: (93.0, 305.0, 93.0),
        };

        let error = statue.get_duration().unwrap_err();
        assert_eq!(error, "Este tipo de item não possui duração.");
    }

    #[test]
    fn test_successful_get_dimensions() {
        let statue = Statue {
            title: "Statue of Liberty".to_string(),
            authors: vec!["Author X".to_string()],
            dimensions: (93.0, 305.0, 93.0),
        };

        let dimensions = statue.get_dimensions().unwrap();
        assert_eq!(dimensions, (93.0, 305.0, Some(93.0)));
    }

    #[test]
    fn test_successful_get_duration() {
        let audiobook = AudioBook {
            title: "Rust Audio".to_string(),
            authors: vec!["Jane Doe".to_string()],
            duration: 120,
        };

        let duration = audiobook.get_duration().unwrap();
        assert_eq!(duration, 120);
    }

    #[test]
    fn test_error_on_get_dimensions_from_audio_book() {
        let audiobook = AudioBook {
            title: "Rust Audio".to_string(),
            authors: vec!["Jane Doe".to_string()],
            duration: 120,
        };

        let error = audiobook.get_dimensions().unwrap_err();
        assert_eq!(error, "Este tipo de item não possui dimensões.");
    }

    #[test]
    fn test_error_on_get_duration_from_painting() {
        let painting = Painting {
            title: "The Starry Night".to_string(),
            authors: vec!["Vincent van Gogh".to_string()],
            dimensions: (0.73, 0.92),
        };

        let error = painting.get_duration().unwrap_err();
        assert_eq!(error, "Este tipo de item não possui duração.");
    }
}


fn main() {
    let mut library = Library::new();

    // Adicionar livros
    library.add_item(
        "978-0-123456-47-2".to_string(),
        Box::new(Book {
            title: "Rust Programming".to_string(),
            authors: vec!["John Doe".to_string(), "Jane Smith".to_string()],
            keywords: vec!["Rust".to_string(), "Programming".to_string()],
        }),
    );
    library.add_item(
        "978-0-987654-32-1".to_string(),
        Box::new(Book {
            title: "Rust Essentials".to_string(),
            authors: vec!["Jane Doe".to_string()],
            keywords: vec!["Rust".to_string(), "Essentials".to_string()],
        }),
    );
    library.add_item(
        "978-0-111111-11-1".to_string(),
        Box::new(Book {
            title: "Mastering Rust".to_string(),
            authors: vec!["Mark Rustacean".to_string()],
            keywords: vec!["Rust".to_string(), "Mastering".to_string()],
        }),
    );

    // Adicionar audiobooks
    library.add_item(
        "audio-001".to_string(),
        Box::new(AudioBook {
            title: "Learn Rust in 24 Hours".to_string(),
            authors: vec!["Alice Johnson".to_string()],
            duration: 480,
        }),
    );
    library.add_item(
        "audio-002".to_string(),
        Box::new(AudioBook {
            title: "Advanced Rust".to_string(),
            authors: vec!["Tom Smith".to_string()],
            duration: 360,
        }),
    );
    library.add_item(
        "audio-003".to_string(),
        Box::new(AudioBook {
            title: "Rust for Professionals".to_string(),
            authors: vec!["Jane Smith".to_string()],
            duration: 600,
        }),
    );

    // Adicionar estátuas
    library.add_item(
        "statue-001".to_string(),
        Box::new(Statue {
            title: "The Thinker".to_string(),
            authors: vec!["Auguste Rodin".to_string()],
            dimensions: (2.5, 3.2, 1.5),
        }),
    );
    library.add_item(
        "statue-002".to_string(),
        Box::new(Statue {
            title: "David".to_string(),
            authors: vec!["Michelangelo".to_string()],
            dimensions: (2.0, 5.17, 1.0),
        }),
    );
    library.add_item(
        "statue-003".to_string(),
        Box::new(Statue {
            title: "Venus de Milo".to_string(),
            authors: vec!["Alexandros of Antioch".to_string()],
            dimensions: (0.6, 2.02, 0.5),
        }),
    );

    // Adicionar quadros
    library.add_item(
        "painting-001".to_string(),
        Box::new(Painting {
            title: "Mona Lisa".to_string(),
            authors: vec!["Leonardo da Vinci".to_string()],
            dimensions: (0.77, 0.53),
        }),
    );
    library.add_item(
        "painting-002".to_string(),
        Box::new(Painting {
            title: "The Starry Night".to_string(),
            authors: vec!["Vincent van Gogh".to_string()],
            dimensions: (0.73, 0.92),
        }),
    );
    library.add_item(
        "painting-003".to_string(),
        Box::new(Painting {
            title: "Guernica".to_string(),
            authors: vec!["Pablo Picasso".to_string()],
            dimensions: (3.5, 7.8),
        }),
    );

    // Mais itens mistos
    library.add_item(
        "978-1-222222-22-2".to_string(),
        Box::new(Book {
            title: "Rust Hacks".to_string(),
            authors: vec!["Michael Rustington".to_string()],
            keywords: vec!["Hacks".to_string()],
        }),
    );
    library.add_item(
        "audio-004".to_string(),
        Box::new(AudioBook {
            title: "Rust Tales".to_string(),
            authors: vec!["Chris Rusted".to_string()],
            duration: 150,
        }),
    );
    library.add_item(
        "statue-004".to_string(),
        Box::new(Statue {
            title: "Statue of Unity".to_string(),
            authors: vec!["Ram V. Sutar".to_string()],
            dimensions: (60.0, 182.0, 80.0),
        }),
    );
    library.add_item(
        "painting-004".to_string(),
        Box::new(Painting {
            title: "The Persistence of Memory".to_string(),
            authors: vec!["Salvador Dalí".to_string()],
            dimensions: (0.24, 0.33),
        }),
    );
    library.add_item(
        "978-3-333333-33-3".to_string(),
        Box::new(Book {
            title: "The Complete Guide to Rust".to_string(),
            authors: vec!["Rust Evangelist".to_string()],
            keywords: vec!["Guide".to_string(), "Complete".to_string()],
        }),
    );
    library.add_item(
        "audio-005".to_string(),
        Box::new(AudioBook {
            title: "Rust in Practice".to_string(),
            authors: vec!["Emily Rust".to_string()],
            duration: 240,
        }),
    );
    library.add_item(
        "statue-005".to_string(),
        Box::new(Statue {
            title: "Christ the Redeemer".to_string(),
            authors: vec!["Paul Landowski".to_string()],
            dimensions: (28.0, 38.0, 8.0),
        }),
    );

    println!("=== Biblioteca com 20 itens criada com sucesso ===");

    // Exemplo: Buscar por autor
    println!("\nItens de 'Jane Smith':");
    for item in library.find_by_author("Jane Smith") {
        println!("{:?}", item);
    }

    // Exemplo: Buscar por título
    println!("\nItens com o título 'Mona Lisa':");
    for item in library.find_by_title("Mona Lisa") {
        println!("{:?}", item);
    }
    // Utilizando o metodo `find_by_author_and_title`
    println!("\nBuscar item usando autor ('Tom Smith') e título ('Advanced Rust'):");
    if let Some(item) = library.find_by_author_and_title("Tom Smith", "Advanced Rust") {
        println!("Item encontrado: {:?}", item);
    } else {
        println!("Nenhum item encontrado com o autor 'Tom Smith' e título 'Advanced Rust'.");
    }

    // Exemplo: Obter uma propriedade específica (Duração do AudioBook)
    println!("\nPropriedade específica (Duração - 'audio-005'):");
    if let Some(item) = library.find_by_id("audio-005") {
        match item.get_duration() {
            Ok(duration) => println!("Duração: {} minutos", duration),
            Err(error) => println!("Erro: {}", error),
        }
    }

    // Exemplo: Obter uma propriedade específica (Dimensões de uma estátua)
    println!("\nPropriedade específica (Dimensões - 'statue-003'):");
    if let Some(item) = library.find_by_id("statue-003") {
        match item.get_dimensions() {
            Ok((width, height, depth)) => {
                println!("Dimensões: largura = {}, altura = {}, profundidade = {:?}", width, height, depth);
            }
            Err(error) => println!("Erro: {}", error),
        }
    }
}

/*fn main() {
    let mut library = Library::new();

    // Adicionar itens à biblioteca.
    library.add_item(
        "978-0-123456-47-2".to_string(),
        Box::new(Book {
            title: "Rust Programming".to_string(),
            authors: vec!["John Doe".to_string(), "Jane Smith".to_string()],
            keywords: vec!["Rust".to_string(), "Programming".to_string()],
        }),
    );

    library.add_item(
        "978-0-987654-32-1".to_string(),
        Box::new(AudioBook {
            title: "Advanced Rust".to_string(),
            authors: vec!["Jane Smith".to_string()],
            duration: 120,
        }),
    );

    library.add_item(
        "statue-001".to_string(),
        Box::new(Statue {
            title: "The Thinker".to_string(),
            authors: vec!["Auguste Rodin".to_string()],
            dimensions: (1.5, 2.5, 1.0),
        }),
    );

    library.add_item(
        "painting-001".to_string(),
        Box::new(Painting {
            title: "Mona Lisa".to_string(),
            authors: vec!["Leonardo da Vinci".to_string()],
            dimensions: (0.77, 0.53),
        }),
    );

    // Busca por título.
    println!("Busca por título ('Mona Lisa'):");
    for item in library.find_by_title("Mona Lisa") {
        println!("{:?}", item);
    }

    // Busca por autor e título.
    println!("\nBusca por autor ('Jane Smith') e título ('Advanced Rust'):");
    if let Some(item) = library.find_by_author_and_title("Jane Smith", "Advanced Rust") {
        println!("{:?}", item);
    }

    // Obter duração de audiobook por ID.
    println!("\nObter duração de audiobook:");
    if let Some(item) = library.find_by_id("978-0-987654-32-1") {
        match item.get_duration() {
            Ok(duration) => println!("Duração: {} minutos", duration),
            Err(e) => println!("{}", e),
        }
    }

    // Obter dimensões de uma estátua.
    println!("\nObter dimensões de uma estátua:");
    if let Some(item) = library.find_by_id("statue-001") {
        match item.get_dimensions() {
            Ok(dimensions) => println!("Dimensões: {:?}", dimensions),
            Err(e) => println!("{}", e),
        }
    }
}

fn main() {
    let mut library = Library::new();

    // Adicionar livros
    library.add_item(
        "978-0-123456-47-2".to_string(),
        Box::new(Book {
            title: "Rust Programming".to_string(),
            authors: vec!["John Doe".to_string(), "Jane Smith".to_string()],
            keywords: vec!["Rust".to_string(), "Programming".to_string()],
        }),
    );
    library.add_item(
        "978-0-987654-32-1".to_string(),
        Box::new(Book {
            title: "Rust Essentials".to_string(),
            authors: vec!["Jane Doe".to_string()],
            keywords: vec!["Rust".to_string(), "Essentials".to_string()],
        }),
    );

    // Adicionar audiobooks
    library.add_item(
        "audio-002".to_string(),
        Box::new(AudioBook {
            title: "Advanced Rust".to_string(),
            authors: vec!["Tom Smith".to_string()],
            duration: 360,
        }),
    );

    // Adicionar quadros
    library.add_item(
        "painting-001".to_string(),
        Box::new(Painting {
            title: "Mona Lisa".to_string(),
            authors: vec!["Leonardo da Vinci".to_string()],
            dimensions: (0.77, 0.53),
        }),
    );

    println!("=== Biblioteca inicializada com sucesso ===");

    // Exemplos de uso:

    // Buscar por autor
    println!("\nItens de 'Jane Smith':");
    for item in library.find_by_author("Jane Smith") {
        println!("{:?}", item);
    }

    // Buscar por título
    println!("\nItens com o título 'Mona Lisa':");
    for item in library.find_by_title("Mona Lisa") {
        println!("{:?}", item);
    }

    // Utilizando o metodo `find_by_author_and_title`
    println!("\nBuscar item usando autor ('Tom Smith') e título ('Advanced Rust'):");
    if let Some(item) = library.find_by_author_and_title("Tom Smith", "Advanced Rust") {
        println!("Item encontrado: {:?}", item);
    } else {
        println!("Nenhum item encontrado com o autor 'Tom Smith' e título 'Advanced Rust'.");
    }

    // Buscar por valores inexistentes
    println!("\nBuscar item usando autor ('Desconhecido') e título ('Inexistente'):");
    if let Some(item) = library.find_by_author_and_title("Desconhecido", "Inexistente") {
        println!("Item encontrado: {:?}", item);
    } else {
        println!("Nenhum item encontrado com o autor 'Desconhecido' e título 'Inexistente'.");
    }
}

 */