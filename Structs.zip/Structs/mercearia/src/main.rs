use std::collections::HashMap;

#[derive(Debug, Clone)]
struct Produto {
    id: u32,
    nome: String,
    data_validade: String,
    preco: f64,
    quantidade: u32,
}

#[derive(Debug, Clone)]
#[derive(Eq, Hash, PartialEq)]
struct Localizacao {
    fileira: u32,
    prateleira: u32,
    zona: char,
}

#[derive(Debug)]
struct Mercearia {
    inventario: HashMap<Localizacao, Vec<Produto>>,
}

impl Mercearia {
    fn new() -> Self {
        Mercearia {
            inventario: HashMap::new(),
        }
    }

    // Adicionar produtos ao inventário em uma localização específica
    fn adicionar_produto(&mut self, localizacao: Localizacao, produto: Produto) {
        self.inventario
            .entry(localizacao)
            .or_insert_with(Vec::new)
            .push(produto);
        println!("Produto adicionado com sucesso!");
    }

    // Remover produto de uma localização específica pelo ID
    fn remover_produto(&mut self, localizacao: &Localizacao, id_produto: u32) {
        if let Some(produtos) = self.inventario.get_mut(localizacao) {
            let tamanho_inicial = produtos.len();
            produtos.retain(|produto| produto.id != id_produto);

            if produtos.len() < tamanho_inicial {
                println!("Produto removido com sucesso!");
            } else {
                println!("Produto não encontrado na localização dada.");
            }
        } else {
            println!("Localização não encontrada!");
        }
    }

    // Mover produto de uma localização para outra
    fn mover_produto(&mut self, origem: &Localizacao, destino: Localizacao, id_produto: u32) {
        if let Some(produtos) = self.inventario.get_mut(origem) {
            if let Some(index) = produtos.iter().position(|p| p.id == id_produto) {
                let produto = produtos.remove(index);
                self.adicionar_produto(destino, produto);
                println!("Produto movido com sucesso!");
            } else {
                println!("Produto não encontrado na localização de origem.");
            }
        } else {
            println!("Localização de origem não encontrada.");
        }
    }

    // Alterar o preço de um produto
    fn alterar_preco(&mut self, localizacao: &Localizacao, id_produto: u32, novo_preco: f64) {
        if let Some(produtos) = self.inventario.get_mut(localizacao) {
            for produto in produtos.iter_mut() {
                if produto.id == id_produto {
                    produto.preco = novo_preco;
                    println!("Preço atualizado com sucesso!");
                    return;
                }
            }
            println!("Produto não encontrado.");
        } else {
            println!("Localização não encontrada.");
        }
    }

    // Alterar o nome de um produto
    fn alterar_nome(&mut self, localizacao: &Localizacao, id_produto: u32, novo_nome: String) {
        if let Some(produtos) = self.inventario.get_mut(localizacao) {
            for produto in produtos.iter_mut() {
                if produto.id == id_produto {
                    produto.nome = novo_nome;
                    println!("Nome atualizado com sucesso!");
                    return;
                }
            }
            println!("Produto não encontrado.");
        } else {
            println!("Localização não encontrada.");
        }
    }

    // Adicionar mais quantidade de um produto (Restock)
    fn adicionar_quantidade(&mut self, localizacao: &Localizacao, id_produto: u32, quantidade: u32) {
        if let Some(produtos) = self.inventario.get_mut(localizacao) {
            for produto in produtos.iter_mut() {
                if produto.id == id_produto {
                    produto.quantidade += quantidade;
                    println!("Restock realizado com sucesso!");
                    return;
                }
            }
            println!("Produto não encontrado.");
        } else {
            println!("Localização não encontrada.");
        }
    }

    // Remover quantidade de um produto
    fn remover_quantidade(&mut self, localizacao: &Localizacao, id_produto: u32, quantidade: u32) {
        if let Some(produtos) = self.inventario.get_mut(localizacao) {
            for produto in produtos.iter_mut() {
                if produto.id == id_produto {
                    if produto.quantidade >= quantidade {
                        produto.quantidade -= quantidade;
                        println!("Quantidade removida com sucesso!");
                    } else {
                        println!("Quantidade a remover excede a disponível!");
                    }
                    return;
                }
            }
            println!("Produto não encontrado.");
        } else {
            println!("Localização não encontrada.");
        }
    }

    // Listar todo o inventário da mercearia
    fn listar_inventario(&self) {
        if self.inventario.is_empty() {
            println!("A mercearia está vazia!");
            return;
        }

        println!("Inventário da Mercearia:");
        for (local, produtos) in &self.inventario {
            println!(
                "Localização - Fileira: {}, Prateleira: {}, Zona: {}",
                local.fileira, local.prateleira, local.zona
            );
            for produto in produtos {
                println!(
                    "    ID: {}, Nome: {}, Validade: {}, Preço: {:.2}, Quantidade: {}",
                    produto.id, produto.nome, produto.data_validade, produto.preco, produto.quantidade
                );
            }
        }
    }
}

fn main() {
    let mut mercearia = Mercearia::new();

    // Criando produtos de exemplo
    let produto1 = Produto {
        id: 1,
        nome: "Maçã".to_string(),
        data_validade: "2026-01-01".to_string(),
        preco: 2.5,
        quantidade: 100,
    };

    let produto2 = Produto {
        id: 2,
        nome: "Banana".to_string(),
        data_validade: "2025-12-10".to_string(),
        preco: 1.5,
        quantidade: 120,
    };

    // Criando localizações
    let local1 = Localizacao {
        fileira: 1,
        prateleira: 1,
        zona: 'A',
    };

    let local2 = Localizacao {
        fileira: 2,
        prateleira: 1,
        zona: 'B',
    };

    // Adicionando produtos ao inventário
    mercearia.adicionar_produto(local1.clone(), produto1);
    mercearia.adicionar_produto(local2.clone(), produto2);

    // Listando o inventário
    mercearia.listar_inventario();

    // Movendo produto
    mercearia.mover_produto(&local2, local1.clone(), 2);

    // Alterando preço e nome
    mercearia.alterar_preco(&local1, 1, 3.0);
    mercearia.alterar_nome(&local1, 1, "Maçã Premium".to_string());

    // Restock e remoção de quantidade
    mercearia.adicionar_quantidade(&local1, 1, 50);
    mercearia.remover_quantidade(&local1, 1, 30);

    // Removendo produto
    mercearia.remover_produto(&local1, 2);

    // Listando o inventário novamente
    mercearia.listar_inventario();
}
