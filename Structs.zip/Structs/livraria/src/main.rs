use std::collections::HashMap;
use std::io;

#[derive(Debug, Clone)]
struct Livro {
    isbn: String,
    titulo: String,
    autor: String,
    palavras_chave: Vec<String>,
}

#[derive(Debug)]
struct Livraria {
    estoque: HashMap<String, (Livro, u32)>, // ISBN -> (Livro, Quantidade em estoque)
}

impl Livraria {
    // Inicializa a livraria
    fn new() -> Self {
        Livraria {
            estoque: HashMap::new(),
        }
    }

    // Adicionar um livro ao estoque
    fn adicionar_livro(&mut self, livro: Livro, quantidade: u32) {
        if let Some(entry) = self.estoque.get_mut(&livro.isbn) {
            entry.1 += quantidade; // Incrementa a quantidade de livros já existentes
        } else {
            self.estoque.insert(livro.isbn.clone(), (livro, quantidade));
        }
        println!("Livro adicionado com sucesso!");
    }

    // Remover um livro do estoque
    fn remover_livro(&mut self, isbn: &str) {
        if self.estoque.remove(isbn).is_some() {
            println!("Livro removido com sucesso!");
        } else {
            println!("Livro com ISBN {} não encontrado no estoque!", isbn);
        }
    }

    // Requisitar um livro (retira um exemplar do estoque)
    fn requisitar_livro(&mut self, isbn: &str) {
        if let Some((_, quantidade)) = self.estoque.get_mut(isbn) {
            if *quantidade > 0 {
                *quantidade -= 1;
                println!("Livro requisitado com sucesso!");
            } else {
                println!("Esse livro está esgotado!");
            }
        } else {
            println!("Livro com ISBN {} não encontrado no estoque!", isbn);
        }
    }

    // Devolver um livro (adiciona um exemplar ao estoque)
    fn devolver_livro(&mut self, isbn: &str) {
        if let Some((_, quantidade)) = self.estoque.get_mut(isbn) {
            *quantidade += 1;
            println!("Livro devolvido com sucesso!");
        } else {
            println!("Livro com ISBN {} não encontrado no estoque!",isbn);
        }
    }

    // Listar todos os livros no estoque
    fn listar_livros(&self) {
        if self.estoque.is_empty() {
            println!("Nenhum livro no estoque!");
        } else {
            println!("Livros no estoque:");
            for (isbn, (livro, quantidade)) in &self.estoque {
                println!(
                    "ISBN: {}, Título: {}, Autor: {}, Palavras-chave: {:?}, Quantidade: {}",
                    isbn, livro.titulo, livro.autor, livro.palavras_chave, quantidade
                );
            }
        }
    }
}

fn main() {
    let mut livraria = Livraria::new();

    loop {
        println!("\n--- Livraria ---");
        println!("1. Adicionar Livro");
        println!("2. Remover Livro");
        println!("3. Requisitar Livro");
        println!("4. Devolver Livro");
        println!("5. Listar Livros");
        println!("0. Sair");
        print!("Escolha uma opção: ");

        // Lê a entrada do usuário
        let mut escolha = String::new();
        io::stdin().read_line(&mut escolha).unwrap();
        let escolha = escolha.trim();

        match escolha {
            "1" => {
                let livro = criar_livro();
                print!("Digite a quantidade de exemplares: ");
                let mut quantidade_str = String::new();
                io::stdin().read_line(&mut quantidade_str).unwrap();
                let quantidade = quantidade_str.trim().parse::<u32>().unwrap_or(1);
                livraria.adicionar_livro(livro, quantidade);
            }
            "2" => {
                print!("Digite o ISBN do livro a remover: ");
                let mut isbn = String::new();
                io::stdin().read_line(&mut isbn).unwrap();
                livraria.remover_livro(isbn.trim());
            }
            "3" => {
                print!("Digite o ISBN do livro a requisitar: ");
                let mut isbn = String::new();
                io::stdin().read_line(&mut isbn).unwrap();
                livraria.requisitar_livro(isbn.trim());
            }
            "4" => {
                print!("Digite o ISBN do livro a devolver: ");
                let mut isbn = String::new();
                io::stdin().read_line(&mut isbn).unwrap();
                livraria.devolver_livro(isbn.trim());
            }
            "5" => livraria.listar_livros(),
            "0" => {
                println!("Saindo...");
                break;
            }
            _ => println!("Opção inválida!"),
        }
    }
}

// Função para criar um novo livro a partir da entrada do usuário
fn criar_livro() -> Livro {
    print!("Digite o ISBN do livro: ");
    let mut isbn = String::new();
    io::stdin().read_line(&mut isbn).unwrap();

    print!("Digite o título do livro: ");
    let mut titulo = String::new();
    io::stdin().read_line(&mut titulo).unwrap();

    print!("Digite o autor do livro: ");
    let mut autor = String::new();
    io::stdin().read_line(&mut autor).unwrap();

    print!("Digite palavras-chave separadas por vírgulas: ");
    let mut palavras_chave_input = String::new();
    io::stdin().read_line(&mut palavras_chave_input).unwrap();
    let palavras_chave: Vec<String> = palavras_chave_input
        .trim()
        .split(',')
        .map(|s| s.trim().to_string())
        .collect();

    Livro {
        isbn: isbn.trim().to_string(),
        titulo: titulo.trim().to_string(),
        autor: autor.trim().to_string(),
        palavras_chave,
    }
}

