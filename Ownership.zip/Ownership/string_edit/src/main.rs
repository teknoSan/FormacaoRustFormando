use std::io;

// Funções para várias manipulações de strings
fn add_to_string(original: &mut String, content: &str) {
    original.push_str(content);
}

fn remove_from_string(original: &mut String, content: &str) {
    *original = original.replacen(content, "", 1);
}

fn to_uppercase(original: &mut String) {
    *original = original.to_uppercase();
}

fn to_lowercase(original: &mut String) {
    *original = original.to_lowercase();
}

fn reverse_string(original: &mut String) {
    *original = original.chars().rev().collect();
}

// Função auxiliar para ler a entrada do usuário
fn read_user_input(prompt: &str) -> String {
    let mut input = String::new();
    println!("{}", prompt);
    io::stdin().read_line(&mut input).expect("Falha ao ler valor inserido.");
    input.trim().to_string()
}

fn main() {
    // 30 strings pré-definidas
    let mut strings = vec![
        "Rust".to_string(), "Programming".to_string(), "Ownership".to_string(),
        "Borrowing".to_string(), "Concurrency".to_string(), "Memory".to_string(),
        "Safety".to_string(), "Fast".to_string(), "Systems".to_string(),
        "Language".to_string(), "Efficient".to_string(), "Error".to_string(),
        "Handling".to_string(), "Compile-Time".to_string(), "Speed".to_string(),
        "Clarity".to_string(), "Zero-Cost".to_string(), "Abstractions".to_string(),
        "Performance".to_string(), "Cross-Platform".to_string(), "Powerful".to_string(),
        "Lifetime".to_string(), "Management".to_string(), "Static".to_string(),
        "Typing".to_string(), "Safe".to_string(), "Modern".to_string(),
        "Flexible".to_string(), "Reliable".to_string(), "Tooling".to_string(),
    ];

    loop {
        println!("\n**** Menu de Edição de Strings ****");
        println!("Escolha uma operação:");
        println!("1. Adicionar texto a uma string");
        println!("2. Remover texto de uma string");
        println!("3. Converter uma string para UPPERCASE");
        println!("4. Converter uma string para lowercase");
        println!("5. Inverter uma string");
        println!("6. Listar todas as strings");
        println!("7. Sair");

        let choice = read_user_input("Insira a sua escolha:");
        match choice.as_str() {
            "1" => {
                // Adicionar texto a uma string
                let index: usize = read_user_input("Insira o índice da string (0-29):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                if index >= strings.len() {
                    println!("Índice inválido.");
                    continue;
                }
                let content = read_user_input("Insira o texto a ser adicionado:");
                add_to_string(&mut strings[index], &content);
                println!("String atualizada: {}", strings[index]);
            }
            "2" => {
                // Remover texto de uma string
                let index: usize = read_user_input("Insira o índice da string (0-29):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                if index >= strings.len() {
                    println!("Índice inválido.");
                    continue;
                }
                let content = read_user_input("Insira o texto a ser removido:");
                remove_from_string(&mut strings[index], &content);
                println!("String atualizada: {}", strings[index]);
            }
            "3" => {
                // Converter para UPPERCASE
                let index: usize = read_user_input("Insira o índice da string (0-29):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                if index >= strings.len() {
                    println!("Índice inválido.");
                    continue;
                }
                to_uppercase(&mut strings[index]);
                println!("String em UPPERCASE: {}", strings[index]);
            }
            "4" => {
                // Converter para lowercase
                let index: usize = read_user_input("Insira o índice da string (0-29):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                if index >= strings.len() {
                    println!("Índice inválido.");
                    continue;
                }
                to_lowercase(&mut strings[index]);
                println!("String em lowercase: {}", strings[index]);
            }
            "5" => {
                // Inverter uma string
                let index: usize = read_user_input("Insira o índice da string (0-29):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                if index >= strings.len() {
                    println!("Índice inválido.");
                    continue;
                }
                reverse_string(&mut strings[index]);
                println!("String invertida: {}", strings[index]);
            }
            "6" => {
                // Listar todas as strings
                println!("\nStrings atuais:");
                for (i, s) in strings.iter().enumerate() {
                    println!("{}: {}", i, s);
                }
            }
            "7" => {
                println!("A Sair...");
                break;
            }
            _ => println!("Opção inválida, tente novamente."),
        }
    }
}
