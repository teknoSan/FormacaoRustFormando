use std::io;

fn apply_operation(value: u32, operation: char, operand: u32) -> u32 {
    match operation {
        '+' => value + operand,
        '-' => value.saturating_sub(operand),
        '*' => value * operand,
        '/' => if operand != 0 { value / operand } else { 0 },
        _ => value,
    }
}

fn mutate_array_by_value(array: [u32; 5], operation: char, operand: u32) -> [u32; 5] {
    array.map(|value| apply_operation(value, operation, operand))
}

fn mutate_array_by_reference(array: &mut [u32], operation: char, operand: u32) {
    for value in array.iter_mut() {
        *value = apply_operation(*value, operation, operand);
    }
}

fn read_user_input(prompt: &str) -> String {
    let mut input = String::new();
    println!("{}", prompt);
    io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
    input.trim().to_string()
}

fn main() {
    loop {
        println!("\nEscolha uma opção:");
        println!("1. Mutar array por valor (retorna novo array)");
        println!("2. Mutar array por referência (modifica in-place)");
        println!("3. Sair");

        let choice = read_user_input("Insira a sua escolha:");

        match choice.as_str() {
            "1" => {
                let array = [1, 2, 3, 4, 5];
                println!("Array inicial (imutável): {:?}", array);

                let operation = read_user_input("Escolha a operação (+, -, *, /):")
                    .chars()
                    .next()
                    .unwrap_or_default();
                let operand: u32 = read_user_input("Informe o operando:")
                    .parse()
                    .expect("Por favor, insira um número válido.");

                let result = mutate_array_by_value(array, operation, operand);
                println!("Novo array (após mutação por valor): {:?}", result);
                println!("Array inicial permanece inalterado: {:?}", array);
            }
            "2" => {
                let mut array = [1, 2, 3, 4, 5];
                println!("Array inicial (mutável): {:?}", array);

                let operation = read_user_input("Escolha a operação (+, -, *, /):")
                    .chars()
                    .next()
                    .unwrap_or_default();
                let operand: u32 = read_user_input("Informe o operando:")
                    .parse()
                    .expect("Por favor, insira um número válido.");

                mutate_array_by_reference(&mut array, operation, operand);
                println!("Array modificado in-place: {:?}", array);
            }
            "3" => {
                println!("A sair...");
                break;
            }
            _ => println!("Opção inválida, tente novamente."),
        }
    }
}
/*use std::io;

fn apply_operation(value: u32, operation: char, operand: u32) -> u32 {
    match operation {
        '+' => value + operand,
        '-' => value.saturating_sub(operand),
        '*' => value * operand,
        '/' => if operand != 0 { value / operand } else { 0 },
        _ => value,
    }
}

fn mutate_array_by_value(array: [u32; 5], operation: char, operand: u32) -> [u32; 5] {
    array.map(|value| apply_operation(value, operation, operand))
}

fn mutate_array_by_reference(array: &mut [u32], operation: char, operand: u32) {
    for value in array.iter_mut() {
        *value = apply_operation(*value, operation, operand);
    }
}

fn main() {
    let mut input = String::new();
    loop {
        println!("\nEscolha uma opção:");
        println!("1. Mutar array por valor (retorna novo array)");
        println!("2. Mutar array por referência (modifica in-place)");
        println!("3. Sair");

        input.clear();
        io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
        let choice = input.trim();

        match choice {
            "1" => {
                let array = [1, 2, 3, 4, 5];
                println!("Array inicial: {:?}", array);

                println!("Escolha a operação (+, -, *, /):");
                input.clear();
                io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
                let operation = input.trim().chars().next().unwrap();

                println!("Informe o operando:");
                input.clear();
                io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
                let operand: u32 = input.trim().parse().expect("Por favor, digite um número válido");

                let result = mutate_array_by_value(array, operation, operand);
                println!("Novo array: {:?}", result);
            }
            "2" => {
                let mut array = [1, 2, 3, 4, 5];
                println!("Array inicial: {:?}", array);

                println!("Escolha a operação (+, -, *, /):");
                input.clear();
                io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
                let operation = input.trim().chars().next().unwrap();

                println!("Informe o operando:");
                input.clear();
                io::stdin().read_line(&mut input).expect("Falha ao ler entrada");
                let operand: u32 = input.trim().parse().expect("Por favor, digite um número válido");

                mutate_array_by_reference(&mut array, operation, operand);
                println!("Array mutado: {:?}", array);
            }
            "3" => {
                println!("Saindo...");
                break;
            }
            _ => println!("Opção inválida, tente novamente."),
        }
    }
}
/*fn array_mut_ownership(array: [u32; 5], operation: char, other_member: u32) -> [u32; 5] {
    todo!()
}

fn array_mut_mut(array: &mut [u32], operation: char, other_member: u32) {
    todo!()
}
*/
#[cfg(test)]
mod array_mutation_test {

    const OWNERSHIP_TEST_ARRAY: [u32; 5] = [1, 2, 3, 4, 5];

    #[test]
    fn test_ownership_mutation() {
        assert_eq!(super::array_mut_ownership(OWNERSHIP_TEST_ARRAY, '+', 1), [2, 3, 4, 5, 6]);
        assert_eq!(super::array_mut_ownership(OWNERSHIP_TEST_ARRAY, '-', 1), [0, 1, 2, 3, 4]);
        assert_eq!(super::array_mut_ownership(OWNERSHIP_TEST_ARRAY, '*', 2), [2, 4, 6, 8, 10]);
        assert_eq!(super::array_mut_ownership(OWNERSHIP_TEST_ARRAY, '/', 2), [0, 1, 1, 2, 2]);
    }

    #[test]
    fn test_mut_ref_mutation() {
        let mut array = OWNERSHIP_TEST_ARRAY.clone();

        super::array_mut_mut(&mut array, '+', 1);

        assert_eq!(array, [2, 3, 4, 5, 6]);

        let mut array = OWNERSHIP_TEST_ARRAY.clone();

        super::array_mut_mut(&mut array, '-', 1);

        assert_eq!(array, [0, 1, 2, 3, 4]);

        let mut array = OWNERSHIP_TEST_ARRAY.clone();

        super::array_mut_mut(&mut array, '*', 2);

        assert_eq!(array, [2, 4, 6, 8, 10]);

        let mut array = OWNERSHIP_TEST_ARRAY.clone();

        super::array_mut_mut(&mut array, '/', 2);

        assert_eq!(array, [0, 1, 1, 2, 2]);
    }

}
*/