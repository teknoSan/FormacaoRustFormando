use std::collections::{HashMap, HashSet};
use std::io;

trait LibraryItem: std::fmt::Debug {
    fn title(&self) -> &String;
    fn authors(&self) -> &Vec<String>;
}

#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

impl LibraryItem for Book {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

#[derive(Debug, Clone)]
struct AudioBook {
    title: String,
    authors: Vec<String>,
    duration: u32, // Em minutos
}

impl LibraryItem for AudioBook {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

#[derive(Debug, Clone)]
struct Statue {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64, f64),
}

impl LibraryItem for Statue {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

#[derive(Debug, Clone)]
struct Painting {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64),
}

impl LibraryItem for Painting {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura da Biblioteca
struct Library {
    items: HashMap<String, Box<dyn LibraryItem>>,
    author_index: HashMap<String, HashSet<String>>,
}

impl Library {
    fn new() -> Self {
        Library {
            items: HashMap::new(),
            author_index: HashMap::new(),
        }
    }

    fn add_item(&mut self, id: String, item: Box<dyn LibraryItem>) {
        let authors = item.authors().clone();
        self.items.insert(id.clone(), item);

        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(id.clone());
        }
    }

    fn find_by_id(&self, id: &str) -> Option<&Box<dyn LibraryItem>> {
        self.items.get(id)
    }

    fn find_by_author(&self, author: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.author_index
            .get(author)
            .map_or(vec![], |ids| {
                ids.iter().filter_map(|id| self.items.get(id)).collect()
            })
    }

    fn list_all_items(&self) {
        println!("Itens na biblioteca:");
        for (id, item) in &self.items {
            println!("ID: {} | Título: {}", id, item.title());
        }
    }
}

fn read_input(prompt: &str) -> String {
    println!("{}", prompt);
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    input.trim().to_string()
}

fn main_menu() {
    println!("\nMenu Biblioteca");
    println!("1) Adicionar Livro");
    println!("2) Adicionar Audiobook");
    println!("3) Adicionar Estátua");
    println!("4) Adicionar Quadro");
    println!("5) Buscar por ID");
    println!("6) Buscar por Autor");
    println!("7) Listar todos os itens");
    println!("0) Sair");
    println!("Escolha uma opção:");
}

fn initialize_library() -> Library {
    let mut library = Library::new();

    // Adicionar objetos predefinidos
    library.add_item(
        "978-0-123456-47-2".to_string(),
        Box::new(Book {
            title: "Rust Programming".to_string(),
            authors: vec!["John Doe".to_string(), "Jane Smith".to_string()],
            keywords: vec!["Rust".to_string(), "Programming".to_string()],
        }),
    );

    library.add_item(
        "audio-123".to_string(),
        Box::new(AudioBook {
            title: "Advanced Rust".to_string(),
            authors: vec!["Jane Smith".to_string()],
            duration: 120,
        }),
    );

    library.add_item(
        "statue-001".to_string(),
        Box::new(Statue {
            title: "The Thinker".to_string(),
            authors: vec!["Auguste Rodin".to_string()],
            dimensions: (1.5, 2.5, 1.0),
        }),
    );

    library.add_item(
        "painting-001".to_string(),
        Box::new(Painting {
            title: "Mona Lisa".to_string(),
            authors: vec!["Leonardo da Vinci".to_string()],
            dimensions: (0.77, 0.53),
        }),
    );

    library
}

fn main() {
    let mut library = initialize_library();

    loop {
        main_menu();

        let choice = read_input("> ");
        match choice.as_str() {
            "1" => {
                let id = read_input("Informe o ID do item:");
                let title = read_input("Informe o título do livro:");
                let authors = read_input("Informe os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let keywords = read_input("Informe as palavras-chave (separadas por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                library.add_item(
                    id,
                    Box::new(Book {
                        title,
                        authors,
                        keywords,
                    }),
                );
                println!("Livro adicionado com sucesso!");
            }
            "2" => {
                let id = read_input("Informe o ID do item:");
                let title = read_input("Informe o título do audiobook:");
                let authors = read_input("Informe os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let duration: u32 = read_input("Informe a duração (em minutos):")
                    .parse()
                    .expect("Por favor, informe um número válido.");
                library.add_item(
                    id,
                    Box::new(AudioBook { title, authors, duration }),
                );
                println!("Audiobook adicionado com sucesso!");
            }
            "3" => {
                let id = read_input("Informe o ID do item:");
                let title = read_input("Informe o título da estátua:");
                let authors = read_input("Informe os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let dimensions: (f64, f64, f64) = (
                    read_input("Informe a largura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Informe a altura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Informe a profundidade:")
                        .parse()
                        .expect("Valor inválido."),
                );
                library.add_item(
                    id,
                    Box::new(Statue {
                        title,
                        authors,
                        dimensions,
                    }),
                );
                println!("Estátua adicionada com sucesso!");
            }
            "4" => {
                let id = read_input("Informe o ID do item:");
                let title = read_input("Informe o título do quadro:");
                let authors = read_input("Informe os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let dimensions: (f64, f64) = (
                    read_input("Informe a largura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Informe a altura:")
                        .parse()
                        .expect("Valor inválido."),
                );
                library.add_item(
                    id,
                    Box::new(Painting {
                        title,
                        authors,
                        dimensions,
                    }),
                );
                println!("Quadro adicionado com sucesso!");
            }
            "5" => {
                let id = read_input("Digite o ID para buscar:");
                if let Some(item) = library.find_by_id(&id) {
                    println!("Item encontrado: {:?}", item);
                } else {
                    println!("Nenhum item encontrado com esse ID.");
                }
            }
            "6" => {
                let author = read_input("Digite o nome do autor:");
                let items = library.find_by_author(&author);
                if items.is_empty() {
                    println!("Nenhum item encontrado para o autor '{}'.", author);
                } else {
                    println!("Itens encontrados para o autor '{}':", author);
                    for item in items {
                        println!("{:?}", item);
                    }
                }
            }
            "7" => {
                library.list_all_items();
            }
            "0" => {
                println!("Saindo do programa.");
                break;
            }
            _ => println!("Opção inválida! Tente novamente."),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_find_predefined_item_by_id() {
        let library = initialize_library();
        assert!(library.find_by_id("978-0-123456-47-2").is_some());
    }

    #[test]
    fn test_find_author_with_items() {
        let library = initialize_library();
        assert_eq!(library.find_by_author("Jane Smith").len(), 2);
    }

    #[test]
    fn test_list_predefined_items() {
        let library = initialize_library();
        assert_eq!(library.items.len(), 4);
    }
}

/*use std::collections::{HashMap, HashSet};
use std::io;

// Define um trait para itens da biblioteca, com propriedades e métodos comuns
trait LibraryItem: std::fmt::Debug {
    fn title(&self) -> &String;
    fn authors(&self) -> &Vec<String>;
}

// Estrutura base: Livro
#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

impl LibraryItem for Book {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Audiobook
#[derive(Debug, Clone)]
struct AudioBook {
    title: String,
    authors: Vec<String>,
    duration: u32, // Em minutos
}

impl LibraryItem for AudioBook {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Estátua
#[derive(Debug, Clone)]
struct Statue {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64, f64), // Largura x Altura x Profundidade
}

impl LibraryItem for Statue {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Quadro
#[derive(Debug, Clone)]
struct Painting {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64), // Largura x Altura
}

impl LibraryItem for Painting {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Biblioteca que suporta itens genéricos
struct Library {
    items: HashMap<String, Box<dyn LibraryItem>>, // Mapear ID/ISBN para itens genéricos
    author_index: HashMap<String, HashSet<String>>, // Autor -> IDs
}

impl Library {
    fn new() -> Self {
        Library {
            items: HashMap::new(),
            author_index: HashMap::new(),
        }
    }

    fn add_item(&mut self, id: String, item: Box<dyn LibraryItem>) {
        let authors = item.authors().clone();

        self.items.insert(id.clone(), item);

        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(id.clone());
        }
    }

    fn find_by_id(&self, id: &str) -> Option<&Box<dyn LibraryItem>> {
        self.items.get(id)
    }

    fn find_by_author(&self, author: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.author_index
            .get(author)
            .map_or(vec![], |ids| {
                ids.iter().filter_map(|id| self.items.get(id)).collect()
            })
    }

    fn list_all_items(&self) {
        println!("Itens na biblioteca:");
        for (id, item) in &self.items {
            println!("ID: {} | Título: {}", id, item.title());
        }
    }
}

fn read_input(prompt: &str) -> String {
    println!("{}", prompt);
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    input.trim().to_string()
}

fn main_menu() {
    println!("\nMenu Biblioteca");
    println!("1) Adicionar Livro");
    println!("2) Adicionar Audiobook");
    println!("3) Adicionar Estátua");
    println!("4) Adicionar Quadro");
    println!("5) Pesquisa por ID");
    println!("6) Pesquisa por Autor");
    println!("7) Listar todos os itens");
    println!("0) Sair");
    println!("Escolha uma opção:");
}

fn main() {
    let mut library = Library::new();

    loop {
        main_menu();

        let choice = read_input("> ");
        match choice.as_str() {
            "1" => {
                let id = read_input("Indique o ID do item:");
                let title = read_input("Indique o título do livro:");
                let authors = read_input("Indique os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let keywords = read_input("Insira as palavras-chave (separadas por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                library.add_item(
                    id,
                    Box::new(Book {
                        title,
                        authors,
                        keywords,
                    }),
                );
                println!("Livro adicionado com sucesso!");
            }
            "2" => {
                let id = read_input("Indique o ID do item:");
                let title = read_input("Indique o título do audiobook:");
                let authors = read_input("Indique os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let duration: u32 = read_input("Indique a duração (em minutos):")
                    .parse()
                    .expect("Por favor, insira um número válido.");
                library.add_item(
                    id,
                    Box::new(AudioBook { title, authors, duration }),
                );
                println!("Audiobook adicionado com sucesso!");
            }
            "3" => {
                let id = read_input("Indique o ID do item:");
                let title = read_input("Indique o título da estátua:");
                let authors = read_input("Indique os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let dimensions: (f64, f64, f64) = (
                    read_input("Indique a largura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Indique a altura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Indique a profundidade:")
                        .parse()
                        .expect("Valor inválido."),
                );
                library.add_item(
                    id,
                    Box::new(Statue {
                        title,
                        authors,
                        dimensions,
                    }),
                );
                println!("Estátua adicionada com sucesso!");
            }
            "4" => {
                let id = read_input("Indique o ID do item:");
                let title = read_input("Indique o título do quadro:");
                let authors = read_input("Indique os autores (separados por vírgula):")
                    .split(',')
                    .map(|s| s.trim().to_string())
                    .collect();
                let dimensions: (f64, f64) = (
                    read_input("Indique a largura:")
                        .parse()
                        .expect("Valor inválido."),
                    read_input("Indique a altura:")
                        .parse()
                        .expect("Valor inválido."),
                );
                library.add_item(
                    id,
                    Box::new(Painting {
                        title,
                        authors,
                        dimensions,
                    }),
                );
                println!("Quadro adicionado com sucesso!");
            }
            "5" => {
                let id = read_input("Digite o ID para pesquisa:");
                if let Some(item) = library.find_by_id(&id) {
                    println!("Item encontrado: {:?}", item);
                } else {
                    println!("Nenhum item encontrado com esse ID.");
                }
            }
            "6" => {
                let author = read_input("Digite o nome do autor:");
                let items = library.find_by_author(&author);
                if items.is_empty() {
                    println!("Nenhum item encontrado para o autor '{}'.", author);
                } else {
                    println!("Itens encontrados para o autor '{}':", author);
                    for item in items {
                        println!("{:?}", item);
                    }
                }
            }
            "7" => library.list_all_items(),
            "0" => {
                println!("A sair do programa.");
                break;
            }
            _ => println!("Opção inválida! Tente novamente."),
        }
    }
}
*/
/*use std::collections::{HashMap, HashSet};

// Define um trait para itens da biblioteca, com propriedades e métodos comuns
trait LibraryItem: std::fmt::Debug {
    fn title(&self) -> &String;
    fn authors(&self) -> &Vec<String>;
}

// Estrutura base: Livro
#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

impl LibraryItem for Book {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Audiobook
#[derive(Debug, Clone)]
struct AudioBook {
    title: String,
    authors: Vec<String>,
    duration: u32, // Em minutos
}

impl LibraryItem for AudioBook {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Estátua
#[derive(Debug, Clone)]
struct Statue {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64, f64), // Largura x Altura x Profundidade
}

impl LibraryItem for Statue {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Estrutura: Quadro
#[derive(Debug, Clone)]
struct Painting {
    title: String,
    authors: Vec<String>,
    dimensions: (f64, f64), // Largura x Altura
}

impl LibraryItem for Painting {
    fn title(&self) -> &String {
        &self.title
    }

    fn authors(&self) -> &Vec<String> {
        &self.authors
    }
}

// Biblioteca que suporta itens genéricos
struct Library {
    items: HashMap<String, Box<dyn LibraryItem>>, // Mapear ID/ISBN para itens genéricos
    author_index: HashMap<String, HashSet<String>>, // Autor -> IDs
}

impl Library {
    fn new() -> Self {
        Library {
            items: HashMap::new(),
            author_index: HashMap::new(),
        }
    }

    fn add_item(&mut self, id: String, item: Box<dyn LibraryItem>) {
        // Adiciona o item ao índice principal
        let authors = item.authors().clone();
        self.items.insert(id.clone(), item);

        // Indexa os autores
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(id.clone());
        }
    }

    fn find_by_id(&self, id: &str) -> Option<&Box<dyn LibraryItem>> {
        self.items.get(id)
    }

    fn find_by_author(&self, author: &str) -> Vec<&Box<dyn LibraryItem>> {
        self.author_index
            .get(author)
            .map_or(vec![], |ids| {
                ids.iter().filter_map(|id| self.items.get(id)).collect()
            })
    }
}

fn main() {
    let mut library = Library::new();

    // Adiciona um livro
    library.add_item(
        "978-0-123456-47-2".to_string(),
        Box::new(Book {
            title: "Rust Programming".to_string(),
            authors: vec!["John Doe".to_string(), "Jane Smith".to_string()],
            keywords: vec!["Rust".to_string(), "Programming".to_string()],
        }),
    );

    // Adiciona um audiobook
    library.add_item(
        "978-0-987654-32-1".to_string(),
        Box::new(AudioBook {
            title: "Advanced Rust".to_string(),
            authors: vec!["Jane Smith".to_string()],
            duration: 120, // 2 horas
        }),
    );

    // Adiciona uma estátua
    library.add_item(
        "statue-001".to_string(),
        Box::new(Statue {
            title: "The Thinker".to_string(),
            authors: vec!["Auguste Rodin".to_string()],
            dimensions: (1.5, 2.5, 1.0), // metros
        }),
    );

    // Adiciona um quadro
    library.add_item(
        "painting-001".to_string(),
        Box::new(Painting {
            title: "Mona Lisa".to_string(),
            authors: vec!["Leonardo da Vinci".to_string()],
            dimensions: (0.77, 0.53), // metros
        }),
    );

    // Busca por ID
    println!("Find by ID:");
    if let Some(item) = library.find_by_id("978-0-123456-47-2") {
        println!("{:?}", item);
    }

    // Busca por Autor
    println!("\nFind by Author (Jane Smith):");
    for item in library.find_by_author("Jane Smith") {
        println!("{:?}", item);
    }
}*/
/*
use std::collections::{HashMap, HashSet};

#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

struct Library {
    books: HashMap<String, Book>,   // ISBN -> Book
    title_index: HashMap<String, String>,  // Title -> ISBN
    author_index: HashMap<String, HashSet<String>>, // Author -> Set of ISBNs
    keyword_index: HashMap<String, HashSet<String>>, // Keyword -> Set of ISBNs
}


impl Library {
    fn new() -> Self {
        Library {
            books: HashMap::new(),
            title_index: HashMap::new(),
            author_index: HashMap::new(),
            keyword_index: HashMap::new(),
        }
    }

    fn add_book(&mut self, isbn: String, title: String, authors: Vec<String>, keywords: Vec<String>) {
        let book = Book {
            title: title.clone(),
            authors: authors.clone(),
            keywords: keywords.clone(),
        };

        self.books.insert(isbn.clone(), book.clone());
        self.title_index.insert(title.clone(), isbn.clone());

        // Index authors
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }

        // Index keywords
        for keyword in keywords {
            self.keyword_index
                .entry(keyword)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }
    }

    fn find_by_isbn(&self, isbn: &str) -> Option<&Book> {
        self.books.get(isbn)
    }

    fn find_by_title(&self, title: &str) -> Option<&Book> {
        self.title_index.get(title).and_then(|isbn| self.books.get(isbn))
    }

    fn find_by_author(&self, author: &str) -> Vec<&Book> {
        self.author_index
            .get(author)
            .map_or(vec![], |isbns| {
                isbns
                    .iter()
                    .filter_map(|isbn| self.books.get(isbn))
                    .collect()
            })
    }
    fn find_by_keywords_intersection(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_intersection = keywords.iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .fold(None, |acc: Option<HashSet<String>>, set| {
                match acc {
                    Some(acc_set) => Some(acc_set.intersection(set).cloned().collect()),
                    None => Some(set.iter().cloned().collect()),
                }
            })
            .unwrap_or_default();

        self.get_books_by_isbns(isbns_intersection)
    }

    fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_union = self.collect_isbns_from_keywords(&keywords);
        self.get_books_by_isbns(isbns_union)
    }




    fn collect_isbns_from_keywords(&self, keywords: &[&str]) -> HashSet<String> {
        keywords
            .iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .flat_map(|isbns| isbns.iter()) // Itera sobre os ISBNs (referências)
            .map(|isbn| isbn.to_string()) // Converte &String para String
            .collect() // Retorna HashSet<String>
    }



    fn get_books_by_isbns<'a>(&'a self, isbns: HashSet<String>) -> Vec<&'a Book> {
        isbns
            .iter()
            .filter_map(|isbn| self.books.get(isbn))
            .collect()
    }


}
fn main() {
    let mut library = Library::new();

    library.add_book(
        "978-0-123456-47-2".to_string(),
        "Rust Programming".to_string(),
        vec!["John Doe".to_string(), "Jane Smith".to_string()],
        vec!["Rust".to_string(), "Programming".to_string(), "Systems".to_string()],
    );

    library.add_book(
        "978-0-987654-32-1".to_string(),
        "Advanced Rust".to_string(),
        vec!["Jane Smith".to_string()],
        vec!["Rust".to_string(), "Advanced".to_string()],
    );

    println!("Find by ISBN:");
    if let Some(book) = library.find_by_isbn("978-0-123456-47-2") {
        println!("{:?}", book);
    }

    println!("\nFind by Title:");
    if let Some(book) = library.find_by_title("Advanced Rust") {
        println!("{:?}", book);
    }

    println!("\nFind by Author (Jane Smith):");
    for book in library.find_by_author("Jane Smith") {
        println!("{:?}", book);
    }

    println!("\nFind by Keywords (Intersection - Rust, Programming):");
    for book in library.find_by_keywords_intersection(vec!["Rust", "Programming"]) {
        println!("{:?}", book);
    }

    println!("\nFind by Keywords (Union - Rust, Advanced):");
    for book in library.find_by_keywords_union(vec!["Rust", "Advanced"]) {
        println!("{:?}", book);
    }
}
*/