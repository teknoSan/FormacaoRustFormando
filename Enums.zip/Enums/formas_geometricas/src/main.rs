use std::f64::consts::PI;
use std::io;

/// Enum que representa as formas geométricas disponíveis
enum Shape {
    Circle,
    Rectangle,
    Triangle,
    Rhombus,
    Pentagon,
    Hexagon,
}

/// Calcula a área de um círculo
fn circle_area(radius: f64) -> f64 {
    PI * radius.powi(2) // Área = πr²
}

/// Calcula a área de um retângulo
fn rectangle_area(width: f64, height: f64) -> f64 {
    width * height // Área = largura * altura
}

/// Calcula a área de um triângulo
fn triangle_area(base: f64, height: f64) -> f64 {
    0.5 * base * height // Área = (base * altura) / 2
}

/// Calcula a área de um losango
fn rhombus_area(diagonal1: f64, diagonal2: f64) -> f64 {
    0.5 * diagonal1 * diagonal2 // Área = (D1 * D2) / 2
}

/// Calcula a área de um pentágono regular
fn regular_pentagon_area(side: f64) -> f64 {
    let apothem = side / (2.0 * (36.0f64.to_radians().tan())); // Cálculo do apótema
    (5.0 * side * apothem) / 2.0 // Área = (Perímetro * Apótema) / 2
}

/// Calcula a área de um hexágono regular
fn regular_hexagon_area(side: f64) -> f64 {
    (3.0 * (3.0f64.sqrt()) * side.powi(2)) / 2.0 // Fórmula específica para hexágono regular
}

/// Função que exibe o menu interativo e recolhe os parâmetros necessários
fn interactive_menu() {
    loop {
        println!("Escolha a forma geométrica para calcular a área:");
        println!("1) Círculo");
        println!("2) Retângulo");
        println!("3) Triângulo");
        println!("4) Losango");
        println!("5) Pentágono regular");
        println!("6) Hexágono regular");
        println!("0) Sair");

        // Lê a escolha do usuário
        let mut choice = String::new();
        io::stdin().read_line(&mut choice).unwrap();
        let choice: u32 = match choice.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Escolha inválida. Tente novamente.\n");
                continue;
            }
        };

        match choice {
            1 => {
                println!("Você escolheu: Círculo");
                let radius = read_input("Informe o raio do círculo: ");
                println!("A área do círculo é: {:.2}\n", circle_area(radius));
            }
            2 => {
                println!("Você escolheu: Retângulo");
                let width = read_input("Informe a largura do retângulo: ");
                let height = read_input("Informe a altura do retângulo: ");
                println!("A área do retângulo é: {:.2}\n", rectangle_area(width, height));
            }
            3 => {
                println!("Você escolheu: Triângulo");
                let base = read_input("Informe a base do triângulo: ");
                let height = read_input("Informe a altura do triângulo: ");
                println!("A área do triângulo é: {:.2}\n", triangle_area(base, height));
            }
            4 => {
                println!("Você escolheu: Losango");
                let diagonal1 = read_input("Informe a diagonal maior do losango: ");
                let diagonal2 = read_input("Informe a diagonal menor do losango: ");
                println!("A área do losango é: {:.2}\n", rhombus_area(diagonal1, diagonal2));
            }
            5 => {
                println!("Você escolheu: Pentágono regular");
                let side = read_input("Informe o lado do pentágono: ");
                println!("A área do pentágono regular é: {:.2}\n", regular_pentagon_area(side));
            }
            6 => {
                println!("Você escolheu: Hexágono regular");
                let side = read_input("Informe o lado do hexágono: ");
                println!("A área do hexágono regular é: {:.2}\n", regular_hexagon_area(side));
            }
            0 => {
                println!("Saindo do programa. Até mais!");
                break;
            }
            _ => println!("Escolha inválida. Tente novamente.\n"),
        }
    }
}

/// Lê a entrada do usuário e converte para `f64`
fn read_input(prompt: &str) -> f64 {
    loop {
        println!("{}", prompt);
        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        match input.trim().parse() {
            Ok(num) => return num,
            Err(_) => println!("Entrada inválida. Tente novamente.\n"),
        }
    }
}

fn main() {
    interactive_menu();
}
/*
use std::f64::consts::PI;

enum Shape {
    Circle { radius: f64 },
    Rectangle { width: f64, height: f64 },
    Triangle { base: f64, height: f64 },
    Rhombus { diagonal1: f64, diagonal2: f64 },
    Pentagon { side: f64 },
    Hexagon { side: f64 },
}

impl Shape {
    /// Calcula a área da forma geométrica
    fn area(&self) -> f64 {
        match self {
            Shape::Circle { radius } => Shape::circle_area(*radius),
            Shape::Rectangle { width, height } => Shape::rectangle_area(*width, *height),
            Shape::Triangle { base, height } => Shape::triangle_area(*base, *height),
            Shape::Rhombus { diagonal1, diagonal2 } => Shape::rhombus_area(*diagonal1, *diagonal2),
            Shape::Pentagon { side } => Shape::regular_pentagon_area(*side),
            Shape::Hexagon { side } => Shape::regular_hexagon_area(*side),
        }
    }

    /// Exibe informações sobre a forma
    fn describe(&self) {
        match self {
            Shape::Circle { radius } => println!("Círculo com raio {:.2}", radius),
            Shape::Rectangle { width, height } => println!(
                "Retângulo com largura {:.2} e altura {:.2}",
                width, height
            ),
            Shape::Triangle { base, height } => println!(
                "Triângulo com base {:.2} e altura {:.2}",
                base, height
            ),
            Shape::Rhombus { diagonal1, diagonal2 } => println!(
                "Losango com diagonal maior {:.2} e diagonal menor {:.2}",
                diagonal1, diagonal2
            ),
            Shape::Pentagon { side } => println!("Pentágono regular com lado {:.2}", side),
            Shape::Hexagon { side } => println!("Hexágono regular com lado {:.2}", side),
        }
    }

    // Funções auxiliares para cálculo de área
    fn circle_area(radius: f64) -> f64 {
        PI * radius.powi(2) // Área = πr²
    }

    fn rectangle_area(width: f64, height: f64) -> f64 {
        width * height // Área = largura * altura
    }

    fn triangle_area(base: f64, height: f64) -> f64 {
        0.5 * base * height // Área = (base * altura) / 2
    }

    fn rhombus_area(diagonal1: f64, diagonal2: f64) -> f64 {
        0.5 * diagonal1 * diagonal2 // Área = (D1 * D2) / 2
    }

    fn regular_pentagon_area(side: f64) -> f64 {
        let apothem = side / (2.0 * (36.0f64.to_radians().tan())); // Lógica para apótema
        (5.0 * side * apothem) / 2.0 // Área = (Perímetro * Apótema) / 2
    }

    fn regular_hexagon_area(side: f64) -> f64 {
        (3.0 * (3.0f64.sqrt()) * side.powi(2)) / 2.0 // Fórmula específica para hexágono regular
    }
}

fn main() {
    // Instâncias das formas geométricas
    let circle = Shape::Circle { radius: 5.0 };
    let rectangle = Shape::Rectangle { width: 10.0, height: 4.0 };
    let triangle = Shape::Triangle { base: 6.0, height: 8.0 };
    let rhombus = Shape::Rhombus { diagonal1: 8.0, diagonal2: 6.0 };
    let pentagon = Shape::Pentagon { side: 5.0 };
    let hexagon = Shape::Hexagon { side: 4.0 };

    // Testar a área e descrição de cada forma
    let shapes = vec![circle, rectangle, triangle, rhombus, pentagon, hexagon];
    for shape in shapes {
        shape.describe();
        println!("Área: {:.2}\n", shape.area());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_circle_area() {
        let circle = Shape::Circle { radius: 3.0 };
        assert!((circle.area() - 28.27).abs() < 0.01);
    }

    #[test]
    fn test_rectangle_area() {
        let rectangle = Shape::Rectangle { width: 5.0, height: 4.0 };
        assert_eq!(rectangle.area(), 20.0);
    }

    #[test]
    fn test_triangle_area() {
        let triangle = Shape::Triangle { base: 6.0, height: 8.0 };
        assert_eq!(triangle.area(), 24.0);
    }

    #[test]
    fn test_rhombus_area() {
        let rhombus = Shape::Rhombus { diagonal1: 8.0, diagonal2: 6.0 };
        assert_eq!(rhombus.area(), 24.0);
    }

    #[test]
    fn test_pentagon_area() {
        let pentagon = Shape::Pentagon { side: 5.0 };
        let expected_area = (5.0 * 5.0 * (36.0_f64.to_radians().tan())) / 2.0; // Área calculada implicitamente
        assert!((pentagon.area() - expected_area).abs() < 0.01);
    }

    #[test]
    fn test_hexagon_area() {
        let hexagon = Shape::Hexagon { side: 4.0 };
        let expected_area = (3.0 * (3.0_f64.sqrt()) * 4.0_f64.powi(2)) / 2.0;
        assert!((hexagon.area() - expected_area).abs() < 0.01);
    }
}
*/
/*
use std::f64::consts::PI;


enum Shape {
    Circle { radius: f64 },
    Rectangle { width: f64, height: f64 },
    Triangle { base: f64, height: f64 },
}

impl Shape {
    /// Calcular a área da forma geométrica
    fn area(&self) -> f64 {
        match self {
            Shape::Circle { radius } => PI * radius.powi(2), // Área = πr²
            Shape::Rectangle { width, height } => width * height, // Área = largura * altura
            Shape::Triangle { base, height } => 0.5 * base * height, // Área = (base * altura) / 2
        }
    }

    /// Exibir informações sobre a forma
    fn describe(&self) {
        match self {
            Shape::Circle { radius } => println!("Círculo com raio {:.2}", radius),
            Shape::Rectangle { width, height } => println!(
                "Retângulo com largura {:.2} e altura {:.2}",
                width, height
            ),
            Shape::Triangle { base, height } => println!(
                "Triângulo com base {:.2} e altura {:.2}",
                base, height
            ),
        }
    }
}

fn main() {
    // Algumas formas geométricas
    let circle = Shape::Circle { radius: 5.0 };
    let rectangle = Shape::Rectangle { width: 10.0, height: 4.0 };
    let triangle = Shape::Triangle { base: 6.0, height: 8.0 };

    // Testar a área e descrição de cada forma
    circle.describe();
    println!("Área do círculo: {:.2}\n", circle.area());

    rectangle.describe();
    println!("Área do retângulo: {:.2}\n", rectangle.area());

    triangle.describe();
    println!("Área do triângulo: {:.2}\n", triangle.area());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_circle_area() {
        let circle = Shape::Circle { radius: 3.0 };
        let area = circle.area();
        assert!((area - 28.27).abs() < 0.01, "Área esperada: ~28.27, encontrada: {:.2}", area);
    }

    #[test]
    fn test_rectangle_area() {
        let rectangle = Shape::Rectangle { width: 5.0, height: 4.0 };
        let area = rectangle.area();
        assert_eq!(area, 20.0, "Área esperada: 20.0, encontrada: {:.2}", area);
    }

    #[test]
    fn test_triangle_area() {
        let triangle = Shape::Triangle { base: 6.0, height: 8.0 };
        let area = triangle.area();
        assert_eq!(area, 24.0, "Área esperada: 24.0, encontrada: {:.2}", area);
    }
}
*/