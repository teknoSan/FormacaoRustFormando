use std::collections::HashMap;
use std::io;

#[derive(Debug, Clone)]
enum Qualidade {
    Fragil { data_validade: u64, max_fileira: usize },
    Oversized { zonas_contiguas: usize },
    Normal,
}

#[derive(Debug, Hash, Eq, PartialEq, Clone)]
struct Localizacao {
    fileira: usize,
    prateleira: usize,
    zona: usize,
}

#[derive(Debug, Clone)]
struct Item {
    id: u64,
    nome: String,
    quantidade: u64,
    qualidade: Qualidade,
    timestamp: u64,
}

struct Armazem {
    mapa: HashMap<Localizacao, Option<Item>>,
}

impl Armazem {
    fn novo(fileiras: usize, prateleiras: usize, zonas: usize) -> Self {
        let mut mapa = HashMap::new();
        for f in 0..fileiras {
            for p in 0..prateleiras {
                for z in 0..zonas {
                    mapa.insert(
                        Localizacao {
                            fileira: f,
                            prateleira: p,
                            zona: z,
                        },
                        None,
                    );
                }
            }
        }
        Self { mapa }
    }

    fn adicionar_item(
        &mut self,
        item: Item,
    ) -> Result<(), String> {
        for (localizacao, slot) in self.mapa.iter_mut() {
            if slot.is_none() {
                *slot = Some(item);
                println!("Item alocado na localização: {:?}", localizacao);
                return Ok(());
            }
        }
        Err("Não há espaço disponível no armazém.".into())
    }

    fn remover_item_da_localizacao(&mut self, posicao: &Localizacao) -> Result<Item, String> {
        if let Some(slot) = self.mapa.get_mut(posicao) {
            if let Some(item) = slot.take() {
                return Ok(item);
            }
        }
        Err("Nenhum item encontrado na localização especificada.".into())
    }

    fn buscar_por_id(&self, id: u64) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(localizacao, slot)| {
                if let Some(item) = slot {
                    if item.id == id {
                        return Some(localizacao.clone());
                    }
                }
                None
            })
            .collect()
    }

    fn buscar_por_nome(&self, nome: &str) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(localizacao, slot)| {
                if let Some(item) = slot {
                    if item.nome.eq_ignore_ascii_case(nome) {
                        return Some(localizacao.clone());
                    }
                }
                None
            })
            .collect()
    }

    fn listar_itens_ordenados(&self) -> Vec<Item> {
        let mut itens: Vec<Item> = self
            .mapa
            .values()
            .filter_map(|slot| slot.clone())
            .collect();
        itens.sort_by(|a, b| a.nome.cmp(&b.nome));
        itens
    }

    fn proximos_do_vencimento(&self, dias: u64, data_atual: u64) -> Vec<Item> {
        self.mapa
            .values()
            .filter_map(|slot| {
                if let Some(item) = slot {
                    if let Qualidade::Fragil { data_validade, .. } = item.qualidade {
                        if data_validade <= data_atual + dias {
                            return Some(item.clone());
                        }
                    }
                }
                None
            })
            .collect()
    }
}

fn menu() {
    let mut armazem = Armazem::novo(3, 3, 3);

    loop {
        println!("\nMenu do Armazém:");
        println!("1. Adicionar item");
        println!("2. Remover item");
        println!("3. Pesquisa de item por ID");
        println!("4. Pesquisa de item por nome");
        println!("5. Listar itens ordenados");
        println!("6. Exibir itens próximos da validade (dias)");
        println!("7. Sair");

        let mut escolha = String::new();
        io::stdin().read_line(&mut escolha).unwrap();
        let escolha = escolha.trim().parse::<u8>();

        match escolha {
            Ok(1) => {
                let item = obter_item();
                match armazem.adicionar_item(item) {
                    Ok(()) => println!("Item adicionado com sucesso!"),
                    Err(e) => println!("Erro ao adicionar item: {}", e),
                }
            }
            Ok(2) => {
                let localizacao = obter_localizacao();
                match armazem.remover_item_da_localizacao(&localizacao) {
                    Ok(item) => println!("Item removido: {:?}", item),
                    Err(e) => println!("Erro ao remover item: {}", e),
                }
            }
            Ok(3) => {
                println!("Digite o ID do item:");
                let mut id = String::new();
                io::stdin().read_line(&mut id).unwrap();
                let id = id.trim().parse::<u64>();
                match id {
                    Ok(id) => {
                        let resultados = armazem.buscar_por_id(id);
                        if resultados.is_empty() {
                            println!("Nenhum item encontrado com o ID especificado.");
                        } else {
                            println!("Item encontrado nas localizações: {:?}", resultados);
                        }
                    }
                    Err(_) => println!("ID inválido."),
                }
            }
            Ok(4) => {
                println!("Insira o nome do item:");
                let mut nome = String::new();
                io::stdin().read_line(&mut nome).unwrap();
                let nome = nome.trim();
                let resultados = armazem.buscar_por_nome(nome);
                if resultados.is_empty() {
                    println!("Nenhum item encontrado com o nome especificado.");
                } else {
                    println!("Item encontrado nas localizações: {:?}", resultados);
                }
            }
            Ok(5) => {
                let itens = armazem.listar_itens_ordenados();
                if itens.is_empty() {
                    println!("Não há itens registados no armazém.");
                } else {
                    for item in itens {
                        println!("{:?}", item);
                    }
                }
            }
            Ok(6) => {
                println!("Insira a quantidade de dias para verificar os itens próximos da validade:");
                let dias = ler_u64();
                println!("Insira a data atual (timestamp) em dias:");
                let data_atual = ler_u64();
                let itens = armazem.proximos_do_vencimento(dias, data_atual);
                if itens.is_empty() {
                    println!("Nenhum item próximo da validade.");
                } else {
                    for item in itens {
                        println!("{:?}", item);
                    }
                }
            }
            Ok(7) => {
                println!("A Sair...");
                break;
            }
            _ => println!("Escolha inválida. Tente novamente."),
        }
    }
}

fn obter_localizacao() -> Localizacao {
    println!("Insira a fileira:");
    let fileira = ler_usize();
    println!("Insira a prateleira:");
    let prateleira = ler_usize();
    println!("Insira a seccao/zona:");
    let zona = ler_usize();
    Localizacao {
        fileira,
        prateleira,
        zona,
    }
}

fn obter_item() -> Item {
    println!("Insira o ID do item:");
    let id = ler_u64();
    println!("Insira o nome do item:");
    let mut nome = String::new();
    io::stdin().read_line(&mut nome).unwrap();
    let nome = nome.trim().to_string();
    println!("Insira a quantidade:");
    let quantidade = ler_u64();

    println!("Escolha a qualidade (1 - Fragil, 2 - Oversized, 3 - Normal):");
    let qualidade = match ler_usize() {
        1 => {
            println!("Insira a data de validade (timestamp):");
            let data_validade = ler_u64();
            println!("Insira o número máximo de fileiras permitido:");
            let max_fileira = ler_usize();
            Qualidade::Fragil {
                data_validade,
                max_fileira,
            }
        }
        2 => {
            println!("Insira o número de zonas contíguas necessárias:");
            let zonas_contiguas = ler_usize();
            Qualidade::Oversized { zonas_contiguas }
        }
        _ => Qualidade::Normal,
    };

    println!("Insira o timestamp:");
    let timestamp = ler_u64();

    Item {
        id,
        nome,
        quantidade,
        qualidade,
        timestamp,
    }
}

fn ler_usize() -> usize {
    let mut entrada = String::new();
    io::stdin().read_line(&mut entrada).unwrap();
    entrada.trim().parse().unwrap_or(0)
}

fn ler_u64() -> u64 {
    let mut entrada = String::new();
    io::stdin().read_line(&mut entrada).unwrap();
    entrada.trim().parse().unwrap_or(0)
}

fn main() {
    menu();
}
/*use std::collections::{BTreeMap, HashMap};
use std::ops::DerefMut;
use std::time::{SystemTime, UNIX_EPOCH};

// Representa a categoria de qualidade do item
#[derive(Debug, Clone)]
enum Qualidade {
    Fragil { data_validade: u64, max_fileira: usize },
    Oversized { zonas_contiguas: usize },
    Normal,
}

// Estrutura para identificar a localização de uma zona no armazém
#[derive(Debug, Hash, Eq, PartialEq, Clone)]
struct Localizacao {
    fileira: usize,
    prateleira: usize,
    zona: usize,
}

// Representa um item no armazém
#[derive(Debug, Clone)]
struct Item {
    id: u64,                  // Identificador numérico
    nome: String,             // Nome do item
    quantidade: u64,          // Quantidade fixa
    qualidade: Qualidade,     // Categoria da qualidade
    timestamp: u64,           // Momento em que o item foi armazenado
}

// Estrutura do armazém
struct Armazem {
    // Representa o mapa físico do armazém
    mapa: HashMap<Localizacao, Option<Item>>,
}

// Contrato para estratégias de alocação
trait EstrategiaAlocacao {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao>;
}

// Estratégia que encontra a zona mais próxima da base
struct ProximaZona;

impl EstrategiaAlocacao for ProximaZona {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao> {
        for (localizacao, ocupado) in &armazem.mapa {
            // Encontra a zona livre mais próxima
            if ocupado.is_none() {
                if let Qualidade::Fragil { max_fileira, .. } = &item.qualidade {
                    if localizacao.fileira > *max_fileira {
                        continue; // Fragilidade não permite fileira tão alta
                    }
                }
                return Some(localizacao.clone());
            }
        }
        None // Nenhuma zona disponível foi encontrada
    }
}

// Estratégia round-robin
struct RoundRobin {
    ultima_zona: Option<Localizacao>,
}

impl EstrategiaAlocacao for RoundRobin {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao> {
        for (localizacao, ocupado) in &armazem.mapa {
            if ocupado.is_none() {
                return Some(localizacao.clone());
            }
        }

        None // Armazém cheio
    }
}

// Trait para filtros de validação e aceitação
trait Filtro {
    fn aceita(&self, armazem: &Armazem, item: &Item) -> bool;
}

// Filtro específico (exemplo de filtro de capacidade máxima no armazém)
struct FiltroCapacidade {
    max_itens: usize,
}

impl Filtro for FiltroCapacidade {
    fn aceita(&self, armazem: &Armazem, _item: &Item) -> bool {
        let ocupados = armazem
            .mapa
            .values()
            .filter(|zona| zona.is_some())
            .count();
        ocupados < self.max_itens
    }
}

impl Armazem {
    // Inicializa o armazém com N fileiras, prateleiras e zonas vazias
    fn novo(fileiras: usize, prateleiras: usize, zonas: usize) -> Self {
        let mut mapa = HashMap::new();
        for fileira in 0..fileiras {
            for prateleira in 0..prateleiras {
                for zona in 0..zonas {
                    mapa.insert(Localizacao { fileira, prateleira, zona }, None);
                }
            }
        }
        Self { mapa }
    }

    // Adiciona um item no armazém
    fn adicionar_item(
        &mut self,
        item: Item,
        alocacao: &dyn EstrategiaAlocacao,
        filtros: &[Box<dyn Filtro>],
    ) -> Result<(), String> {
        for filtro in filtros {
            if !filtro.aceita(self, &item) {
                return Err("Item não aceito pelos filtros".to_string());
            }
        }

        if let Some(localizacao) = alocacao.alocar(&item, self) {
            self.mapa.insert(localizacao, Some(item));
            Ok(())
        } else {
            Err("Não foi possível alocar o item".to_string())
        }
    }

    // Remove um item pela localização
    /*fn remover_item(&mut self, localizacao: &Localizacao) -> Result<Item, String> {
        if let Some(Some(item)) = self.mapa.get_mut(localizacao) {
            let item_removido = item.clone();
            *item = None;
            Ok(item_removido)
        } else {
            Err("Nenhum item encontrado na zona especificada".to_string())
        }
    }*/
    fn remover_item_da_localizacao(&mut self, posicao: &Localizacao) -> Result<Item, String> {
        const ERRO_ITEM_NAO_ENCONTRADO: &str = "Nenhum item encontrado na zona especificada";

        let entrada = self.mapa.get_mut(posicao);

        if let Some(Some(item)) = entrada {
            let item_removido = item.clone();
            //*item = self.deref_mut(); // Marca o item na posição como removido
            Ok(item_removido)
        } else {
            Err(ERRO_ITEM_NAO_ENCONTRADO.to_string())
        }
    }

    // Realiza buscas eficientes usando `HashMap`
    fn buscar_por_id(&self, id: u64) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(local, item)| {
                if let Some(item) = item {
                    if item.id == id {
                        return Some(local.clone());
                    }
                }
                None
            })
            .collect()
    }

    fn buscar_por_nome(&self, nome: &str) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(local, item)| {
                if let Some(item) = item {
                    if item.nome == nome {
                        return Some(local.clone());
                    }
                }
                None
            })
            .collect()
    }

    // Retorna os itens armazenados ordenados pelo nome
    fn listar_itens_ordenados(&self) -> Vec<Item> {
        let mut itens: Vec<Item> = self
            .mapa
            .values()
            .filter_map(|item| item.clone())
            .collect();
        itens.sort_by(|a, b| a.nome.cmp(&b.nome));
        itens
    }

    // Busca itens que estão a 3 dias ou menos do vencimento
    fn proximos_do_vencimento(&self, dias: u64) -> Vec<Item> {
        let agora = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
        self.mapa
            .values()
            .filter_map(|item| {
                if let Some(item) = item {
                    if let Qualidade::Fragil { data_validade, .. } = item.qualidade {
                        if data_validade <= agora + (dias * 86400) {
                            return Some(item.clone());
                        }
                    }
                }
                None
            })
            .collect()
    }
}

/*use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, UNIX_EPOCH};

// Representa a categoria de qualidade do item
#[derive(Debug, Clone)]
enum Qualidade {
    Fragil { data_validade: u64, max_fileira: usize },
    Oversized { zonas_contiguas: usize },
    Normal,
}

// Estrutura para identificar a localização de uma zona no armazém
#[derive(Debug, Hash, Eq, PartialEq, Clone)]
struct Localizacao {
    fileira: usize,
    prateleira: usize,
    zona: usize,
}

// Representa um item no armazém
#[derive(Debug, Clone)]
struct Item {
    id: u64,                  // Identificador numérico
    nome: String,             // Nome do item
    quantidade: u64,          // Quantidade fixa
    qualidade: Qualidade,     // Categoria da qualidade
    timestamp: u64,           // Momento em que o item foi armazenado
}

// Estrutura do armazém
struct Armazem {
    // Representa o mapa físico do armazém
    mapa: HashMap<Localizacao, Option<Item>>,
}

// Contrato para estratégias de alocação
trait EstrategiaAlocacao {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao>;
}

// Estratégia que encontra a zona mais próxima da base
struct ProximaZona;

impl EstrategiaAlocacao for ProximaZona {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao> {
        for (localizacao, ocupado) in &armazem.mapa {
            // Encontra a zona livre mais próxima
            if ocupado.is_none() {
                if let Qualidade::Fragil { max_fileira, .. } = &item.qualidade {
                    if localizacao.fileira > *max_fileira {
                        continue; // Fragilidade não permite fileira tão alta
                    }
                }
                return Some(localizacao.clone());
            }
        }
        None // Nenhuma zona disponível foi encontrada
    }
}

// Estratégia round-robin
struct RoundRobin {
    ultima_zona: Option<Localizacao>,
}

impl EstrategiaAlocacao for RoundRobin {
    fn alocar(&self, item: &Item, armazem: &Armazem) -> Option<Localizacao> {
        let mut encontrado = false;
        for (localizacao, ocupado) in &armazem.mapa {
            if ocupado.is_none() {
                encontrado = true;
                return Some(localizacao.clone());
            }
        }

        if !encontrado {
            // Caso o armazém esteja cheio
            return None;
        }

        None
    }
}

// Trait para filtros de validação e aceitação
trait Filtro {
    fn aceita(&self, armazem: &Armazem, item: &Item) -> bool;
}

// Filtro específico (exemplo de filtro de capacidade máxima no armazém)
struct FiltroCapacidade {
    max_itens: usize,
}

impl Filtro for FiltroCapacidade {
    fn aceita(&self, armazem: &Armazem, _item: &Item) -> bool {
        let ocupados = armazem
            .mapa
            .values()
            .filter(|zona| zona.is_some())
            .count();
        ocupados < self.max_itens
    }
}

impl Armazem {
    // Inicializa o armazém com N fileiras, prateleiras e zonas vazias
    fn novo(fileiras: usize, prateleiras: usize, zonas: usize) -> Self {
        let mut mapa = HashMap::new();
        for fileira in 0..fileiras {
            for prateleira in 0..prateleiras {
                for zona in 0..zonas {
                    mapa.insert(Localizacao { fileira, prateleira, zona }, None);
                }
            }
        }
        Self { mapa }
    }

    // Adiciona um item no armazém
    fn adicionar_item(
        &mut self,
        item: Item,
        alocacao: &dyn EstrategiaAlocacao,
        filtros: &[Box<dyn Filtro>],
    ) -> Result<(), String> {
        for filtro in filtros {
            if !filtro.aceita(self, &item) {
                return Err("Item não aceito pelos filtros".to_string());
            }
        }

        if let Some(localizacao) = alocacao.alocar(&item, self) {
            self.mapa.insert(localizacao, Some(item));
            Ok(())
        } else {
            Err("Não foi possível alocar o item".to_string())
        }
    }

    // Remove um item pela localização
    fn remover_item(&mut self, localizacao: &Localizacao) -> Result<Item, String> {
        if let Some(slot) = self.mapa.get_mut(localizacao) {
            if let Some(item) = slot.take() {
                Ok(item)
            } else {
                Err("Nenhum item encontrado na zona especificada".to_string())
            }
        } else {
            Err("Nenhuma localização encontrada".to_string())
        }
    }

    // Realiza buscas eficientes usando `HashMap`
    fn buscar_por_id(&self, id: u64) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(local, item)| {
                if let Some(item) = item {
                    if item.id == id {
                        return Some(local.clone());
                    }
                }
                None
            })
            .collect()
    }

    fn buscar_por_nome(&self, nome: &str) -> Vec<Localizacao> {
        self.mapa
            .iter()
            .filter_map(|(local, item)| {
                if let Some(item) = item {
                    if item.nome == nome {
                        return Some(local.clone());
                    }
                }
                None
            })
            .collect()
    }

    // Retorna os itens armazenados ordenados pelo nome
    fn listar_itens_ordenados(&self) -> Vec<Item> {
        let mut itens: Vec<Item> = self
            .mapa
            .values()
            .filter_map(|item| item.clone())
            .collect();
        itens.sort_by(|a, b| a.nome.cmp(&b.nome));
        itens
    }

    // Busca itens que estão a 3 dias ou menos do vencimento
    fn proximos_do_vencimento(&self, dias: u64) -> Vec<Item> {
        let agora = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
        self.mapa
            .values()
            .filter_map(|item| {
                if let Some(item) = item {
                    if let Qualidade::Fragil { data_validade, .. } = item.qualidade {
                        if data_validade <= agora + (dias * 86400) {
                            return Some(item.clone());
                        }
                    }
                }
                None
            })
            .collect()
    }
}
*/
fn main() {
    // Exemplo de inicialização e uso do armazém
    let mut armazem = Armazem::novo(10, 5, 3);

    // Cria filtros, estratégia de alocação e adiciona itens ao armazém
    let filtros: Vec<Box<dyn Filtro>> = vec![Box::new(FiltroCapacidade { max_itens: 100 })];
    let estrategia = ProximaZona;

    let item = Item {
        id: 1,
        nome: "Item Frágil".to_string(),
        quantidade: 10,
        qualidade: Qualidade::Fragil {
            data_validade: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs() + 86400,
            max_fileira: 2,
        },
        timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
    };

    armazem.adicionar_item(item, &estrategia, &filtros).unwrap();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_adicionar_item_com_sucesso() {
        let mut armazem = Armazem::novo(3, 3, 3);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let item = Item {
            id: 1,
            nome: "Item Teste".to_string(),
            quantidade: 50,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        let result = armazem.adicionar_item(item.clone(), &estrategia, &filtros);
        assert!(result.is_ok()); // O item foi adicionado com sucesso
        let localizacoes = armazem.buscar_por_id(item.id);
        assert_eq!(localizacoes.len(), 1);
    }

    #[test]
    fn test_buscar_item_por_id() {
        let mut armazem = Armazem::novo(2, 2, 2);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let item = Item {
            id: 101,
            nome: "Item Especial".to_string(),
            quantidade: 10,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        armazem.adicionar_item(item.clone(), &estrategia, &filtros).unwrap();
        let resultado = armazem.buscar_por_id(101);

        assert_eq!(resultado.len(), 1);
    }

    #[test]
    fn test_buscar_item_por_nome() {
        let mut armazem = Armazem::novo(2, 2, 2);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let item = Item {
            id: 202,
            nome: "Item Nomeado".to_string(),
            quantidade: 5,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        armazem.adicionar_item(item.clone(), &estrategia, &filtros).unwrap();
        let resultado = armazem.buscar_por_nome("Item Nomeado");

        assert_eq!(resultado.len(), 1);
    }

    #[test]
    fn test_remover_item() {
        let mut armazem = Armazem::novo(2, 2, 2);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let item = Item {
            id: 303,
            nome: "Item a Remover".to_string(),
            quantidade: 3,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        armazem.adicionar_item(item.clone(), &estrategia, &filtros).unwrap();
        let localizacao = armazem.buscar_por_id(303).into_iter().next().unwrap();
        let resultado = armazem.remover_item_da_localizacao(&localizacao);

        assert!(resultado.is_ok());
        assert_eq!(resultado.unwrap().id, 303);
        assert!(armazem.buscar_por_id(303).is_empty());
    }

    #[test]
    fn test_proximos_do_vencimento() {
        let mut armazem = Armazem::novo(2, 2, 2);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let agora = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();

        let item_a_vencer = Item {
            id: 404,
            nome: "Item a Vencer".to_string(),
            quantidade: 1,
            qualidade: Qualidade::Fragil {
                data_validade: agora + 86400, // 1 dia
                max_fileira: 1,
            },
            timestamp: agora,
        };

        let item_valido = Item {
            id: 405,
            nome: "Item Valido".to_string(),
            quantidade: 2,
            qualidade: Qualidade::Fragil {
                data_validade: agora + 86400 * 10, // 10 dias
                max_fileira: 1,
            },
            timestamp: agora,
        };

        armazem.adicionar_item(item_a_vencer.clone(), &estrategia, &filtros).unwrap();
        armazem.adicionar_item(item_valido.clone(), &estrategia, &filtros).unwrap();

        let proximos = armazem.proximos_do_vencimento(3); // Filtro de 3 dias
        assert_eq!(proximos.len(), 1);
        assert_eq!(proximos[0].id, 404);
    }
    use std::collections::HashMap;
    use std::io;

    // Estruturas de dados
    #[derive(Debug, Clone)]
    struct Localizacao {
        fileira: usize,
        prateleira: usize,
        zona: usize,
    }

    #[derive(Debug, Clone)]
    struct Item {
        id: u64,
        nome: String,
        quantidade: u64,
        qualidade: String,
    }

    struct Armazem {
        mapa: HashMap<Localizacao, Item>,
    }

    // Implementação do armazém
    impl Armazem {
        fn novo() -> Self {
            Armazem {
                mapa: HashMap::new(),
            }
        }

        fn inserir_item(&mut self, localizacao: Localizacao, item: Item) -> Result<(), String> {
            if self.mapa.contains_key(&localizacao) {
                Err("Essa localização já contém um item!".to_string())
            } else {
                self.mapa.insert(localizacao, item);
                Ok(())
            }
        }

        fn atualizar_item(&mut self, localizacao: &Localizacao, item_atualizado: Item) -> Result<(), String> {
            if self.mapa.contains_key(localizacao) {
                self.mapa.insert(localizacao.clone(), item_atualizado);
                Ok(())
            } else {
                Err("Não existe nenhum item nesta localização para atualizar!".to_string())
            }
        }

        fn listar_itens(&self) {
            if self.mapa.is_empty() {
                println!("O armazém está vazio.");
            } else {
                for (localizacao, item) in &self.mapa {
                    println!(
                        "Localização {:?}: Item: {} (ID: {}, Quantidade: {}, Qualidade: {})",
                        localizacao, item.nome, item.id, item.quantidade, item.qualidade
                    );
                }
            }
        }

        fn eliminar_item(&mut self, localizacao: &Localizacao) -> Result<Item, String> {
            if let Some(item_removido) = self.mapa.remove(localizacao) {
                Ok(item_removido)
            } else {
                Err("Nenhum item encontrado na localização fornecida.".to_string())
            }
        }
    }

    // Funções auxiliares para entrada de dados
    fn menu() {
        println!("\n=== Sistema de Gestão do Armazém ===");
        println!("1. Inserir Item");
        println!("2. Atualizar Item");
        println!("3. Listar Itens");
        println!("4. Eliminar Item");
        println!("0. Sair");
        print!("Escolha uma opção: ");
        _ = io::Write::flush(&mut io::stdout());
    }

    fn obter_localizacao() -> Localizacao {
        let mut input = String::new();

        println!("Digite a fileira:");
        io::stdin().read_line(&mut input).unwrap();
        let fileira: usize = input.trim().parse().expect("Valor inválido!");

        input.clear();
        println!("Digite a prateleira:");
        io::stdin().read_line(&mut input).unwrap();
        let prateleira: usize = input.trim().parse().expect("Valor inválido!");

        input.clear();
        println!("Digite a zona:");
        io::stdin().read_line(&mut input).unwrap();
        let zona: usize = input.trim().parse().expect("Valor inválido!");

        Localizacao {
            fileira,
            prateleira,
            zona,
        }
    }

    fn obter_item() -> Item {
        let mut input = String::new();

        println!("Digite o ID do item:");
        io::stdin().read_line(&mut input).unwrap();
        let id: u64 = input.trim().parse().expect("Valor inválido!");

        input.clear();
        println!("Digite o nome do item:");
        io::stdin().read_line(&mut input).unwrap();
        let nome = input.trim().to_string();

        input.clear();
        println!("Digite a quantidade do item:");
        io::stdin().read_line(&mut input).unwrap();
        let quantidade: u64 = input.trim().parse().expect("Valor inválido!");

        input.clear();
        println!("Digite a qualidade do item:");
        io::stdin().read_line(&mut input).unwrap();
        let qualidade = input.trim().to_string();

        Item {
            id,
            nome,
            quantidade,
            qualidade,
        }
    }

    // Função principal
    fn main() {
        let mut armazem = Armazem::novo();

        // Dados pré-definidos
        armazem
            .inserir_item(
                Localizacao {
                    fileira: 1,
                    prateleira: 1,
                    zona: 1,
                },
                Item {
                    id: 101,
                    nome: "Produto A".to_string(),
                    quantidade: 10,
                    qualidade: "Normal".to_string(),
                },
            )
            .unwrap();

        armazem
            .inserir_item(
                Localizacao {
                    fileira: 2,
                    prateleira: 1,
                    zona: 3,
                },
                Item {
                    id: 102,
                    nome: "Produto B".to_string(),
                    quantidade: 20,
                    qualidade: "Alta".to_string(),
                },
            )
            .unwrap();

        // Loop do menu
        loop {
            menu();
            let mut escolha = String::new();
            io::stdin().read_line(&mut escolha).unwrap();
            let escolha = escolha.trim();

            match escolha {
                "1" => {
                    let localizacao = obter_localizacao();
                    let item = obter_item();
                    match armazem.inserir_item(localizacao, item) {
                        Ok(_) => println!("Item inserido com sucesso!"),
                        Err(e) => println!("Erro: {}", e),
                    }
                }
                "2" => {
                    let localizacao = obter_localizacao();
                    let item_atualizado = obter_item();
                    match armazem.atualizar_item(&localizacao, item_atualizado) {
                        Ok(_) => println!("Item atualizado com sucesso!"),
                        Err(e) => println!("Erro: {}", e),
                    }
                }
                "3" => {
                    armazem.listar_itens();
                }
                "4" => {
                    let localizacao = obter_localizacao();
                    match armazem.eliminar_item(&localizacao) {
                        Ok(item_removido) => println!("Item removido: {:?}", item_removido),
                        Err(e) => println!("Erro: {}", e),
                    }
                }
                "0" => {
                    println!("Encerrando o sistema...");
                    break;
                }
                _ => println!("Opção inválida!"),
            }
        }
    }

    #[test]
    fn test_lista_ordenada_por_nome() {
        let mut armazem = Armazem::novo(2, 2, 2);
        let estrategia = ProximaZona;
        let filtros: Vec<Box<dyn Filtro>> = Vec::new();

        let item_b = Item {
            id: 1,
            nome: "Item B".to_string(),
            quantidade: 5,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        let item_a = Item {
            id: 2,
            nome: "Item A".to_string(),
            quantidade: 3,
            qualidade: Qualidade::Normal,
            timestamp: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
        };

        armazem.adicionar_item(item_b, &estrategia, &filtros).unwrap();
        armazem.adicionar_item(item_a, &estrategia, &filtros).unwrap();

        let itens_ordenados = armazem.listar_itens_ordenados();
        assert_eq!(itens_ordenados.len(), 2);
        assert_eq!(itens_ordenados[0].nome, "Item A");
        assert_eq!(itens_ordenados[1].nome, "Item B");
    }
}

*/
 */
