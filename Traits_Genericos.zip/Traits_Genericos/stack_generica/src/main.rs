use std::ops::{Add, Sub};

pub struct Stack<T> {
    elements: Vec<T>,    // Usando Vec para armazenar os elementos
    capacity: Option<usize>, // Capacidade máxima (None = ilimitado)
    sum: Option<T>,          // Soma dos elementos, se T suportar Add e Clone
}

impl<T> Stack<T>
where
    T: Add<Output = T> + Sub<Output = T> + Default + Clone, // / + std::ops::Sub<Output = T>,
{
    /// Cria uma nova stack vazia.
    /// Capacidade máxima pode ser definida (opcional).
    pub fn new(capacity: Option<usize>) -> Self {
        Stack {
            elements: Vec::new(),
            capacity,
            sum: Some(T::default()), // Soma inicializada com o valor padrão (0 para números)
        }
    }

    /// Adiciona um elemento no topo da stack.
    /// Retorna `Err` se a capacidade máxima for atingida.
    pub fn push(&mut self, item: T) -> Result<(), String> {
        if let Some(cap) = self.capacity {
            if self.elements.len() >= cap {
                return Err("Capacidade máxima atingida".to_string());
            }
        }

        self.sum = Some(self.sum.clone().unwrap() + item.clone()); // Atualiza a soma
        self.elements.push(item); // Adiciona o elemento
        Ok(())
    }

    /// Remove e retorna o elemento do topo da stack.
    /// Também atualiza a soma.
    pub fn pop(&mut self) -> Option<T> {
        if let Some(value) = self.elements.pop() {
            self.sum = Some(self.sum.clone().unwrap() - value.clone());
            Some(value)
        } else {
            None
        }
    }

    /// Retorna uma referência ao elemento do topo sem removê-lo.
    pub fn peek(&self) -> Option<&T> {
        self.elements.last()
    }

    /// Retorna o número de elementos presentes na stack.
    pub fn size(&self) -> usize {
        self.elements.len()
    }

    /// Retorna `true` se a stack estiver vazia.
    pub fn is_empty(&self) -> bool {
        self.elements.is_empty()
    }

    /// Retorna a soma de todos os elementos, se aplicável.
    pub fn get_sum(&self) -> Option<T> {
        self.sum.clone()
    }
}
fn main() {
    // Criar uma pilha com uma capacidade máxima de 5 elementos
    let mut limited_stack = Stack::new(Some(5));

    // Empilhar alguns números
    limited_stack.push(10).unwrap();
    limited_stack.push(20).unwrap();
    limited_stack.push(30).unwrap();

    println!("Topo da stack: {:?}", limited_stack.peek()); // Saída: Some(30)
    println!("Tamanho: {}", limited_stack.size()); // Saída: 3
    println!("Soma atual: {:?}", limited_stack.get_sum()); // Saída: Some(60)

    // Excedendo a capacidade
    if let Err(e) = limited_stack.push(40) {
        println!("Erro ao empilhar: {}", e); // Saída: Capacidade máxima atingida
    }

    // Desempilhar elementos
    println!("Desempilhar: {:?}", limited_stack.pop()); // Saída: Some(30)
    println!("Soma após pop: {:?}", limited_stack.get_sum()); // Saída: Some(30)

    // Criar uma stack ilimitada
    let mut unlimited_stack = Stack::new(None);
    unlimited_stack.push(100).unwrap();
    unlimited_stack.push(200).unwrap();

    println!("Stack ilimitada soma: {:?}", unlimited_stack.get_sum()); // Saída: Some(300)
}

#[cfg(test)]
mod tests {
    use super::*; // Importa a definição do módulo atual

    #[test]
    fn test_stack_push_and_pop() {
        // Criar uma stack limitada com tamanho 3
        let mut stack = Stack::new(Some(3));

        // Adicionar elementos na stack
        stack.push(10).unwrap();
        stack.push(20).unwrap();
        stack.push(30).unwrap();

        // Extra: verifica se a capacidade máxima funciona
        assert_eq!(stack.push(40), Err("Capacidade máxima atingida".to_string()));

        // Testa o valor do topo após inserir elementos
        assert_eq!(stack.peek(), Some(&30));

        // Remove elementos e testa a ordem correta (LIFO - Last In, First Out)
        assert_eq!(stack.pop(), Some(30));
        assert_eq!(stack.pop(), Some(20));
        assert_eq!(stack.pop(), Some(10));

        // Stack deve estar vazia depois de todos os pops
        assert_eq!(stack.is_empty(), true);

        // Testa o valor retornado ao tentar pop em uma stack vazia
        assert_eq!(stack.pop(), None);
    }

    #[test]
    fn test_stack_size_and_is_empty() {
        let mut stack = Stack::new(None); // Stack ilimitada

        // A stack está vazia inicialmente
        assert_eq!(stack.is_empty(), true);
        assert_eq!(stack.size(), 0);

        // Adicionar elementos
        stack.push(1).unwrap();
        stack.push(2).unwrap();
        stack.push(3).unwrap();

        // Verificar o tamanho atualizado
        assert_eq!(stack.size(), 3);
        assert_eq!(stack.is_empty(), false);
    }

    #[test]
    fn test_stack_sum() {
        let mut stack = Stack::new(Some(5));

        // Adicionar números e verificar a soma acumulada
        stack.push(10).unwrap();
        assert_eq!(stack.get_sum(), Some(10));

        stack.push(20).unwrap();
        assert_eq!(stack.get_sum(), Some(30));

        stack.push(30).unwrap();
        assert_eq!(stack.get_sum(), Some(60));

        // Remover um elemento e verificar a soma
        stack.pop();
        assert_eq!(stack.get_sum(), Some(30));
    }

    #[test]
    fn test_stack_with_negative_numbers() {
        let mut stack = Stack::new(None);

        // Adicionar números negativos e verificar soma
        stack.push(-10).unwrap();
        stack.push(-20).unwrap();
        stack.push(30).unwrap();

        assert_eq!(stack.get_sum(), Some(0));

        // Remover elemento e verificar nova soma
        stack.pop();
        assert_eq!(stack.get_sum(), Some(-30));
    }
}



