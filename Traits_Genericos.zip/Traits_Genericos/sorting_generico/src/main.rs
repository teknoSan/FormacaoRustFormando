use std::cmp::Ordering;
use std::fmt::{Debug, Display};

/// Enum que define os tipos de algoritmos de ordenação
pub enum SortingAlgorithm {
    Bubble,
    Selection,
}

/// Struct `Sorter` que gere uma lista genérica e realiza as ordenações
pub struct Sorter<'a, T> {
    data: &'a mut Vec<T>, // Referência mutável à lista a ser ordenada
}

impl<'a, T> Sorter<'a, T>
where
    T: Ord, // Restrições para que o tipo seja ordenável
{
    /// Criação de uma nova instância do Sorter com uma referência à lista
    pub fn new(data: &'a mut Vec<T>) -> Self {
        Self { data }
    }

    /// Aplica o algoritmo específico na lista
    pub fn sort(&mut self, algorithm: SortingAlgorithm) {
        match algorithm {
            SortingAlgorithm::Bubble => self.bubble_sort(),
            SortingAlgorithm::Selection => self.selection_sort(),
        }
    }

    /// Implementação do Bubble Sort
    fn bubble_sort(&mut self) {
        let n = self.data.len();
        for i in 0..n {
            for j in 0..n - 1 - i {
                if self.data[j] > self.data[j + 1] {
                    self.data.swap(j, j + 1);
                }
            }
        }
    }

    /// Implementação do Selection Sort
    fn selection_sort(&mut self) {
        let n = self.data.len();
        for i in 0..n {
            let mut min_index = i;
            for j in (i + 1)..n {
                if self.data[j] < self.data[min_index] {
                    min_index = j;
                }
            }
            if min_index != i {
                self.data.swap(i, min_index);
            }
        }
    }
}

/// Exemplos de enums que representam diferentes tipos de dados
#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Fruit {
    Apple,
    Banana,
    Orange,
    Grape,
    Watermelon,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Colors {
    Red,
    Blue,
    Green,
    Yellow,
    Black,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Weather {
    Sunny,
    Rainy,
    Cloudy,
    Snowy,
    Windy,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Vehicle {
    Car,
    Bike,
    Truck,
    Bus,
    Train,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Days {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
}

/// Exemplos de structs que encapsulam diferentes tipos de dados
#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Person {
    pub name: String,
    pub age: u8,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Point {
    pub x: i32,
    pub y: i32,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Book {
    pub title: String,
    pub year: u16,
}

#[derive(Debug)]
#[derive(PartialEq)]
struct Temperature {
    pub city: String,
    pub celsius: f64,
}

#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Score {
    pub player: String,
    pub points: u32,
}
impl Eq for Temperature {}
// Implementação de PartialOrd (requisito para Ord)
impl PartialOrd for Temperature {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Temperature {
    fn cmp(&self, other: &Self) -> Ordering {
        // Comparação ignorando os casos de NaN
        self.city.cmp(&other.city).then_with(|| {
            self.celsius
                .partial_cmp(&other.celsius)
                .unwrap_or(Ordering::Equal) // Tratar NaN como sendo igual (ajuste conforme necessidade)
        })
    }
}

/// Função principal
fn main() {

    let mut temps = vec![
        Temperature {
            city: "CityA".to_string(),
            celsius: 25.0,
        },
        Temperature {
            city: "CityB".to_string(),
            celsius: 30.0,
        },
        Temperature {
            city: "CityC".to_string(),
            celsius: f64::NAN,
        },
    ];

    temps.sort();

    for temp in temps {
        println!("{:?}", temp);
    }

    // Ordenando com enums
    let mut fruits = vec![
        Fruit::Orange,
        Fruit::Apple,
        Fruit::Watermelon,
        Fruit::Grape,
        Fruit::Banana,
    ];
    let mut sorter = Sorter::new(&mut fruits);
    sorter.sort(SortingAlgorithm::Bubble);
    println!("Frutas ordenadas: {:?}", sorter.data);

    let mut vehicles = vec![
        Vehicle::Train,
        Vehicle::Car,
        Vehicle::Bike,
        Vehicle::Bus,
        Vehicle::Truck,
    ];
    let mut sorter = Sorter::new(&mut vehicles);
    sorter.sort(SortingAlgorithm::Selection);
    println!("Veículos ordenados: {:?}", sorter.data);

    // Ordenando com structs
    let mut people = vec![
        Person {
            name: String::from("Alice"),
            age: 30,
        },
        Person {
            name: String::from("Bob"),
            age: 25,
        },
        Person {
            name: String::from("Charlie"),
            age: 35,
        },
    ];
    let mut sorter = Sorter::new(&mut people);
    sorter.sort(SortingAlgorithm::Bubble);
    println!("Pessoas ordenadas: {:?}", sorter.data);

    let mut books = vec![
        Book {
            title: String::from("Rust in Action"),
            year: 2021,
        },
        Book {
            title: String::from("The Rust Programming Language"),
            year: 2019,
        },
        Book {
            title: String::from("Programming Rust"),
            year: 2020,
        },
    ];
    let mut sorter = Sorter::new(&mut books);
    sorter.sort(SortingAlgorithm::Selection);
    println!("Livros ordenados: {:?}", sorter.data);

    let mut scores = vec![
        Score {
            player: String::from("Player1"),
            points: 150,
        },
        Score {
            player: String::from("Player2"),
            points: 300,
        },
        Score {
            player: String::from("Player3"),
            points: 200,
        },
    ];
    let mut sorter = Sorter::new(&mut scores);
    sorter.sort(SortingAlgorithm::Bubble);
    println!("Pontuações ordenadas: {:?}", sorter.data);
}
