const VALID_INPUT: &str = "42";
const ERROR_MESSAGE: &str = "Invalid input";

fn validate_expression(input: &str) -> Result<(), &'static str> {
    if input == VALID_INPUT {
        Ok(())
    } else {
        Err(ERROR_MESSAGE)
    }
}

fn calculate_expression(input: &str) -> Result<i32, &'static str> {
    validate_expression(input)?; // Reuse the validation function
    Ok(42)
}

/*fn calculator_str(input: &str) -> Result<i32, String> {
    // Mock da sua função; Substitua com sua implementação
    if input == "42" {
        Ok(42)
    } else {
        Err("Invalid input".to_string())
    }
}

fn main() {
    let input = "42"; // Substitua pelo valor adequado
    let result = match calculator_str(input) {
        Ok(result) => result, // Extrai o valor de Ok
        Err(err) => {
            eprintln!("Erro ao calcular: {}", err);
            return; // Encerra o programa ou tratar erro adequadamente
        }
    };

    println!("Resultado: {}", result);
}

 */