fn calculator_str(input: &str) -> Result<i32, String> {
    // Mock da sua função; Substitua com sua implementação
    if input == "42" {
        Ok(42)
    } else {
        Err("Invalid input".to_string())
    }
}

fn main() {
    let input = "42"; // Substitua pelo valor adequado
    let result = match calculator_str(input) {
        Ok(result) => result, // Extrai o valor de Ok
        Err(err) => {
            eprintln!("Erro ao calcular: {}", err);
            return; // Encerra o programa ou tratar erro adequadamente
        }
    };

    println!("Resultado: {}", result);
}