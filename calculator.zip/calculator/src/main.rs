///4 x 456mod calculator_input_validation;
///mod calculator_with_error_handling;

use std::io::{self, Write};

fn main() {
    println!("Bem-vindo à RustCalculadora!");
    println!("Insira uma operação, por exemplo: '2 * 3' para calcular.");
    println!("Digite 'sair' para encerrar.");

    loop {
        print!("Operação: ");
        io::stdout().flush().unwrap(); // Garante que o texto seja exibido antes do user inserir algo

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        let input = input.trim();

        if input.to_lowercase() == "sair" {
            println!("Encerrando a calculadora!");
            break;
        }

        match calculator_str(input) {
            Ok(result) => println!("Resultado: {}", result),
            Err(err) => eprintln!("Erro: {}", err), // Imprime erros amigáveis
        }
    }
}

fn calculator_str(string: &str) -> Result<f64, String> {
    let tokens: Vec<&str> = string.split_whitespace().collect();
    if tokens.len() != 3 {
        return Err("Formato inválido! Use: 'a operador b' (exemplo: '2 + 3')".to_string());
    }

    // Parse dos números com validação de erros (agora para f64)
    let a = tokens[0].parse::<f64>().map_err(|_| "O primeiro número não é válido!".to_string())?;
    let b = tokens[2].parse::<f64>().map_err(|_| "O segundo número não é válido!".to_string())?;
    let operator = tokens[1];

    // Processa os operadores
    match operator {
        "+" => Ok(a + b),
        "-" => Ok(a - b),
        "*" => Ok(a * b),
        "/" => {
            if b == 0.0 {
                Err("Erro: Divisão por zero!".to_string())
            } else {
                Ok(a / b)
            }
        }
        _ => Err("Operador inválido! Use apenas +, -, * ou /".to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculator_str_success() {
        assert_eq!(calculator_str("1 + 1"), Ok(2.0));
        assert_eq!(calculator_str("7 - 3"), Ok(4.0));
        assert_eq!(calculator_str("6 * 2"), Ok(12.0));
        assert_eq!(calculator_str("8 / 2"), Ok(4.0));
        assert_eq!(calculator_str("5 / 2"), Ok(2.5)); // Agora aceita resultados decimais
    }

    #[test]
    fn test_calculator_str_errors() {
        // Input inválido
        assert!(calculator_str("1").is_err());
        assert!(calculator_str("2 ^ 2").is_err());

        // Operadores inválidos
        assert_eq!(
            calculator_str("2 ^ 2"),
            Err("Operador inválido! Use apenas +, -, * ou /".to_string())
        );

        // Divisão por zero
        assert_eq!(
            calculator_str("2 / 0"),
            Err("Erro: Divisão por zero!".to_string())
        );

        // Número inválido
        assert_eq!(
            calculator_str("a + 1"),
            Err("O primeiro número não é válido!".to_string())
        );
        assert_eq!(
            calculator_str("2 + b"),
            Err("O segundo número não é válido!".to_string())
        );
    }
}
/*use std::io::{self, Write};

fn main() {
    println!("Bem-vindo à calculadora!");
    println!("Insira uma operação, por exemplo: '2 * 3' para calcular.");
    println!("Digite 'sair' para encerrar.");

    loop {
        print!("Operação: ");
        io::stdout().flush().unwrap(); // Garante que o texto seja exibido antes de o usuário inserir algo

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        let input = input.trim();

        if input.to_lowercase() == "sair" {
            println!("Encerrando a calculadora!");
            break;
        }

        match calculator_str(input) {
            Ok(result) => println!("Resultado: {}", result),
            Err(err) => eprintln!("Erro: {}", err), // Imprime erros amigáveis
        }
    }
}

fn calculator_str(string: &str) -> Result<i32, String> {
    let tokens: Vec<&str> = string.split_whitespace().collect();
    if tokens.len() != 3 {
        return Err("Formato inválido! Use: 'a operador b' (exemplo: '2 + 3')".to_string());
    }

    // Parse dos números com validação de erros
    let a = tokens[0].parse::<i32>().map_err(|_| "O primeiro número não é válido!".to_string())?;
    let b = tokens[2].parse::<i32>().map_err(|_| "O segundo número não é válido!".to_string())?;
    let operator = tokens[1];

    // Processa os operadores
    match operator {
        "+" => Ok(a + b),
        "-" => Ok(a - b),
        "*" => Ok(a * b),
        "/" => {
            if b == 0 {
                Err("Erro: Divisão por zero!".to_string())
            } else {
                Ok(a / b)
            }
        }
        _ => Err("Operador inválido! Use apenas +, -, * ou /".to_string()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculator_str_success() {
        assert_eq!(calculator_str("1 + 1"), Ok(2));
        assert_eq!(calculator_str("7 - 3"), Ok(4));
        assert_eq!(calculator_str("6 * 2"), Ok(12));
        assert_eq!(calculator_str("8 / 2"), Ok(4));
    }

    #[test]
    fn test_calculator_str_errors() {
        // Input inválido
        assert!(calculator_str("1").is_err());
        assert!(calculator_str("2 ^ 2").is_err());

        // Operadores inválidos
        assert_eq!(
            calculator_str("2 ^ 2"),
            Err("Operador inválido! Use apenas +, -, * ou /".to_string())
        );

        // Divisão por zero
        assert_eq!(
            calculator_str("2 / 0"),
            Err("Erro: Divisão por zero!".to_string())
        );

        // Número inválido
        assert_eq!(
            calculator_str("a + 1"),
            Err("O primeiro número não é válido!".to_string())
        );
        assert_eq!(
            calculator_str("2 + b"),
            Err("O segundo número não é válido!".to_string())
        );
    }
}
*/
/*mod calculator_input_validation;
mod calculator_with_error_handling;

/// Desafio da calculadora
/// Pode ser implementado com recurso à análise de apenas
/// uma string ou com cada elemento separado na sua propria string.
/// Podem ver exemplos de como vai ser utilizada a função nos testes disponíveis.
///
/// Devem apenas implementar uma das funções.
///
/// Podem comentar a função que não vão implementar para não haver problemas de compilação, incluindo os testes
/// para a mesma.
//use std::{io, result};
use std::{io};
use std::io::Write;
//use meval::eval_str;
//use std::io::{self, Write}; // Para lidar com input/output

fn main() {
    /* todo!("Implementar a leitura do stdin") */
    println!("Bem-vindo à calculadora! Insira uma operação por exemplo '2 * 3' para calcular (ou digite 'sair' para encerrar):");
    loop {
        print!("Operação: ");
        io::stdout().flush().unwrap();

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        let input = input.trim();

        if input == "sair" {
            println!("Encerrando a calculadora!");
            break;
        }

        // Você pode escolher qual implementação usar aqui
        let result: i32 = match calculator_str(input) {
            Ok(result) => result,
            Err(err) => {
                eprintln!("Erro: {}", err);
                continue;
            }
        };

        println!("Resultado: {}", result);
    }

}


fn calculator_str(string: &str) -> Result<i32, String> {
    /* todo!("Implementar a calculadora que de uma string calcule o resultado") */
    let tokens: Vec<&str> = string.split_whitespace().collect();
    if tokens.len() != 3 {
        panic!("Formato inválido! A string deve estar no formato 'a operador b'");
    }

    let a = tokens[0].parse::<i32>().expect("Erro ao converter o primeiro número");
    let b = tokens[2].parse::<i32>().expect("Erro ao converter o segundo número");
    let operator = tokens[1];

    match operator {
        "+" => Ok(a + b),
        "-" => Ok(a - b),
        "*" => Ok(a * b),
        "/" => Ok(a / b),
        _ => Err("Operador inválido! Use apenas +, -, * ou /".to_string()),
    }

}

fn calculator_str_list(string: &[&str]) -> i32 {
    /* todo!("Implementar a calculadora que de uma string ou de uma lista de strings calcule o resultado") */
    unimplemented!("Esta função não foi implementada ainda.");

    if string.len() != 3 {
        panic!("Formato inválido! A lista deve conter exatamente 3 elementos: ['a', 'operador', 'b']");
    }

    let a = string[0].parse::<i32>().expect("Erro ao converter o primeiro número");
    let b = string[2].parse::<i32>().expect("Erro ao converter o segundo número");
    let operator = string[1];

    match operator {
        "+" => a + b,
        "-" => a - b,
        "*" => a * b,
        "/" => a / b,
        _ => panic!("Operador inválido! Use apenas +, -, * ou /"),
    }

}

#[cfg(test)]
pub mod calculator_test {

    #[test]
    fn test_calculator_str() {
        assert_eq!(super::calculator_str("1 + 1"), Ok(2));
        assert_eq!(super::calculator_str("2 * 2"), Ok(4));
        assert_eq!(super::calculator_str("2 / 2"), Ok(1));
        assert_eq!(super::calculator_str("2 - 2"), Ok(0));
    }

    #[test]
    #[ignore]
    fn test_calculator_str_list() {
        assert_eq!(super::calculator_str_list(&vec!["2", "*", "3"]), 6);
        assert_eq!(super::calculator_str_list(&vec!["2", "+", "3"]), 5);
        assert_eq!(super::calculator_str_list(&vec!["3", "-", "2"]), 0);
        assert_eq!(super::calculator_str_list(&vec!["6", "/", "3"]), 2);
    }

}

 */