
use std::env;

fn main() {
    // Verificar automaticamente o intervalo de 0 a 10000
    //let range = 0..=100000_000;
    let range = 0..=10000;

    println!("Verificar números primos no intervalo de 0 a 10000:");
    for number in range {
        if check_if_prime(number) {
            println!("{} é um número primo.", number);
        }
    }
    println!("Verificação automática concluída.\n");

    // Parte 2: Verificar números fornecidos na linha de comando
    let args: Vec<String> = env::args().skip(1).collect(); // Ignorar o primeiro argumento (nome do programa)

    if !args.is_empty() {
        println!("Verificar números fornecidos na linha de comandos:");

        for arg in args {
            match arg.parse::<u32>() {
                Ok(number) => {
                    if check_if_prime(number) {
                        println!("{} é um número primo.", number);
                    } else {
                        println!("{} não é um número primo.", number);
                    }
                }
                Err(_) => {
                    eprintln!("Erro: '{}' não é um número válido.", arg);
                }
            }
        }
    } else {
        println!("Não foi fornecido na linha de comandos qualquer número para verificar.");
    }
}

fn check_if_prime(n: u32) -> bool {
    /*todo!("Implementar check_if_prime aqui")*/

    if n < 2 {
        return false;
    }
    for i in 2..=((n as f64).sqrt() as u32) {
        if n % i == 0 {
            return false;
        }
    }
    true
}

#[cfg(test)]
mod prime_checker_test {

    #[test]
    fn test_check_if_prime() {
        assert_eq!(super::check_if_prime(0), false);
        assert_eq!(super::check_if_prime(1), false);
        assert_eq!(super::check_if_prime(2), true);
        assert_eq!(super::check_if_prime(3), true);
        assert_eq!(super::check_if_prime(4), false);
        assert_eq!(super::check_if_prime(5), true);
        assert_eq!(super::check_if_prime(6), false);
        assert_eq!(super::check_if_prime(7), true);
        assert_eq!(super::check_if_prime(8), false);
        assert_eq!(super::check_if_prime(9), false);
        assert_eq!(super::check_if_prime(10), false);
        assert_eq!(super::check_if_prime(11), true);
        assert_eq!(super::check_if_prime(12), false);
        assert_eq!(super::check_if_prime(13), true);
        assert_eq!(super::check_if_prime(14), false);
        assert_eq!(super::check_if_prime(15), false);
        assert_eq!(super::check_if_prime(16), false);
        assert_eq!(super::check_if_prime(17), true);
        assert_eq!(super::check_if_prime(18), false);
        assert_eq!(super::check_if_prime(19), true);
        assert_eq!(super::check_if_prime(20), false);
        assert_eq!(super::check_if_prime(21), false);
        assert_eq!(super::check_if_prime(22), false);
        assert_eq!(super::check_if_prime(23), true);
        assert_eq!(super::check_if_prime(24), false);
        assert_eq!(super::check_if_prime(25), false);
        assert_eq!(super::check_if_prime(26), false);
        assert_eq!(super::check_if_prime(27), false);
        assert_eq!(super::check_if_prime(28), false);
        assert_eq!(super::check_if_prime(29), true);
        assert_eq!(super::check_if_prime(30), false);
        assert_eq!(super::check_if_prime(31), true);
        assert_eq!(super::check_if_prime(32), false);
        assert_eq!(super::check_if_prime(33), false);
        assert_eq!(super::check_if_prime(34), false);
        assert_eq!(super::check_if_prime(35), false);
    }
}

//use std::env;
/*fn main() {

    // Obtém os argumentos fornecidos na linha de comando
    let args: Vec<String> = env::args().collect();

    // Verifica se o utilizador forneceu um número como argumento
    if args.len() != 2 {
        eprintln!("Uso: {} <número>", args[0]);
        /*std::process::exit(1);*/
        panic!("Erro");
    };

    // Converte o argumento para um número inteiro
    let number: u32 = match args[1].parse() {
        Ok(n) => n,
        Err(_) => {
            eprintln!("Erro: O argumento fornecido não é um número válido.");
            /*std::process::exit(1);*/
            panic!();
        }
    };



        /*std::process::exit(1);
    }
};*/

// Verifica se o número é primo
if check_if_prime(number) {
println!("{} é um número primo.", number);
} else {
println!("{} não é um número primo.", number);
}
}

fn check_if_prime(n: u32) -> bool {
    /*todo!("Implementar check_if_prime aqui")*/
    if n < 2 {
        return false;
    }
    for i in 2..=((n as f64).sqrt() as u32) {
        if n % i == 0 {
            return false;
        }
    }
    true

}

#[cfg(test)]
mod prime_checker_test {

    #[test]
    fn test_check_if_prime() {
        assert_eq!(super::check_if_prime(0), false);
        assert_eq!(super::check_if_prime(1), false);
        assert_eq!(super::check_if_prime(2), true);
        assert_eq!(super::check_if_prime(3), true);
        assert_eq!(super::check_if_prime(4), false);
        assert_eq!(super::check_if_prime(5), true);
        assert_eq!(super::check_if_prime(6), false);
        assert_eq!(super::check_if_prime(7), true);
        assert_eq!(super::check_if_prime(8), false);
        assert_eq!(super::check_if_prime(9), false);
        assert_eq!(super::check_if_prime(10), false);
        assert_eq!(super::check_if_prime(11), true);
        assert_eq!(super::check_if_prime(12), false);
        assert_eq!(super::check_if_prime(13), true);
        assert_eq!(super::check_if_prime(14), false);
        assert_eq!(super::check_if_prime(15), false);
        assert_eq!(super::check_if_prime(16), false);
        assert_eq!(super::check_if_prime(17), true);
        assert_eq!(super::check_if_prime(18), false);
        assert_eq!(super::check_if_prime(19), true);
        assert_eq!(super::check_if_prime(20), false);
        assert_eq!(super::check_if_prime(21), false);
        assert_eq!(super::check_if_prime(22), false);
        assert_eq!(super::check_if_prime(23), true);
        assert_eq!(super::check_if_prime(24), false);
        assert_eq!(super::check_if_prime(25), false);
        assert_eq!(super::check_if_prime(26), false);
        assert_eq!(super::check_if_prime(27), false);
        assert_eq!(super::check_if_prime(28), false);
        assert_eq!(super::check_if_prime(29), true);
        assert_eq!(super::check_if_prime(30), false);
        assert_eq!(super::check_if_prime(31), true);
        assert_eq!(super::check_if_prime(32), false);
        assert_eq!(super::check_if_prime(33), false);
        assert_eq!(super::check_if_prime(34), false);
        assert_eq!(super::check_if_prime(35), false);
    }
}*/
/*fn main() {
    // Define o intervalo de 0 a 10.000
    let range = 0..=10_000;

    println!("Verificar existência de números primos no intervalo de 0 a 10000...");


    for number in range {
        if check_if_prime(number) {
            println!("{} é um número primo.", number);
        }
    }
    println!("Verificação concluída.");
}

fn check_if_prime(n: u32) -> bool {
    if n < 2 {
        return false;
    }
    for i in 2..=((n as f64).sqrt() as u32) {
        if n % i == 0 {
            return false;
        }
    }
    true
}

#[cfg(test)]
mod prime_checker_test {

    #[test]
    fn test_check_if_prime() {
        assert_eq!(super::check_if_prime(0), false);
        assert_eq!(super::check_if_prime(1), false);
        assert_eq!(super::check_if_prime(2), true);
        assert_eq!(super::check_if_prime(3), true);
        assert_eq!(super::check_if_prime(4), false);
        assert_eq!(super::check_if_prime(5), true);
        assert_eq!(super::check_if_prime(6), false);
        assert_eq!(super::check_if_prime(7), true);
        assert_eq!(super::check_if_prime(8), false);
        assert_eq!(super::check_if_prime(9), false);
        assert_eq!(super::check_if_prime(10), false);
        assert_eq!(super::check_if_prime(11), true);
        assert_eq!(super::check_if_prime(12), false);
        assert_eq!(super::check_if_prime(13), true);
        assert_eq!(super::check_if_prime(14), false);
        assert_eq!(super::check_if_prime(15), false);
        assert_eq!(super::check_if_prime(16), false);
        assert_eq!(super::check_if_prime(17), true);
        assert_eq!(super::check_if_prime(18), false);
        assert_eq!(super::check_if_prime(19), true);
        assert_eq!(super::check_if_prime(20), false);
        assert_eq!(super::check_if_prime(21), false);
        assert_eq!(super::check_if_prime(22), false);
        assert_eq!(super::check_if_prime(23), true);
        assert_eq!(super::check_if_prime(24), false);
        assert_eq!(super::check_if_prime(25), false);
        assert_eq!(super::check_if_prime(26), false);
        assert_eq!(super::check_if_prime(27), false);
        assert_eq!(super::check_if_prime(28), false);
        assert_eq!(super::check_if_prime(29), true);
        assert_eq!(super::check_if_prime(30), false);
        assert_eq!(super::check_if_prime(31), true);
        assert_eq!(super::check_if_prime(32), false);
        assert_eq!(super::check_if_prime(33), false);
        assert_eq!(super::check_if_prime(34), false);
        assert_eq!(super::check_if_prime(35), false);
    }
}

*/