fn achatar_deduplicar_filtrar(v: Vec<Vec<u32>>) -> Vec<u32> {//1. O código recebe v: Vec<Vec<u32>>, um vetor onde cada elemento é outro vetor (`Vec<u32>`).
                                                                // Exemplos de entrada podem incluir algo como:   vec![vec![1, 2, 3], vec![3, 4, 5], vec![6, 6, 9]]

    v.into_iter()      //A função retornará um vetor plano (Vec<u32>) após realizar os passos seguintes.
        //1. Aqui, o metodo `.into_iter()` consome o vetor externo (Vec<Vec<u32>>) e cria um iterator que itera sobre os seus elementos, cada um sendo um vetor interior (Vec<u32>).


        .flatten()        //
                                //1. **Achatar o vetor (flatten):**
                                // O metodo `.flatten()` transforma Vec<Vec<u32>> (um vetor de vetores) num único iterator de números inteiros.
                                // Ele "achata" os elementos internos de todos os vetores: por exemplo, vec![vec![1, 2, 3], vec![3, 4, 5], vec![6, 6, 9]] se transformaria em
                                //    vec![1, 2, 3, 3, 4, 5, 6, 6, 9]
        .filter(|&x| x % 2 == 0 || x % 3 == 0)
                               //1. **Filtrar os números:**
                                // O metodo `.filter()` retorna apenas os números que atendem à condição especificada.
                                //  A condição é que o número seja divisível por 2 **ou** por 3:
                                //Isso significa que a função descarta números que **não são divisíveis por 2 ou 3**.
                                // Exemplo: Para o vetor achatado acima ([1, 2, 3, 3, 4, 5, 6, 6, 9]), o filtro retornaria: [2, 3, 3, 4, 6, 6, 9]
        .collect::<std::collections::HashSet<_>>()
                                //1. O metodo .collect() consome os elementos do iterator atual e os insere numa coleção
                                // — no caso, um HashSet. Um HashSet em Rust é uma coleção que não permite valores duplicados.
                                //Após a conversão para HashSet ficaria:  {2, 3, 4, 6, 9}  // (exemplo de conjunto, a ordem não é garantida)
        .into_iter()
                                //1. **Converter de volta em um iterator:**
                                // O HashSet resultante é transformado novamente num iterator com `.into_iter()`.
                                // Isso torna possível coletar os valores únicos numa nova estrutura de dados.
        .collect()
                               //1. **Transformar o iterator em Vec<u32>:**
                                    // Finalmente, o metodo .collect() consome o iterator e o converte num Vec<u32>.
                                    //1. Resultado:
                                //vec![2, 3, 4, 6, 9] // A ordem pode variar, pois HashSet não garante ordem.
                                //### Observação:
                                // Se for necessário garantir a ordem dos elementos na saída, você precisaria de uma abordagem diferente,
                                // usando algo como um BTreeSet (que organiza os valores em ordem), ou coletando diretamente em um Vec e então ordenando.

}

fn main() {
    // Exemplo de uso da função
    let vec = vec![vec![1, 2, 3], vec![3, 4, 5], vec![5, 6, 7], vec![12,14,15], vec![22,34,45]];
    let resultado = achatar_deduplicar_filtrar(vec);

    // Imprimir o resultado
    println!("Resultado filtrado e sem dados duplicados: {:?}", resultado);
}


#[cfg(test)]
mod achatar_deduplicar_filtrar_test {
    use std::collections::HashSet;

    #[test]
    fn test_func() {

        let vec = vec![vec![1, 2, 3], vec![3, 4, 5], vec![5, 6, 7]];

        let result = super::achatar_deduplicar_filtrar(vec);

        assert!(result.iter().all(|x| x % 2 == 0 || x % 3 == 0));

        let mut seen = HashSet::new();

        assert!(result.iter().all(|x| seen.insert(x)));
    }

}