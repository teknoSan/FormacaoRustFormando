use std::collections::{HashMap, HashSet};

#[derive(Debug, Clone)]
struct Book {
    title: String,
    authors: Vec<String>,
    keywords: Vec<String>,
}

struct Library {
    books: HashMap<String, Book>,   // ISBN -> Book
    title_index: HashMap<String, String>,  // Title -> ISBN
    author_index: HashMap<String, HashSet<String>>, // Author -> Set of ISBNs
    keyword_index: HashMap<String, HashSet<String>>, // Keyword -> Set of ISBNs
}

impl Library {
    fn new() -> Self {
        Library {
            books: HashMap::new(),
            title_index: HashMap::new(),
            author_index: HashMap::new(),
            keyword_index: HashMap::new(),
        }
    }

    fn add_book(&mut self, isbn: String, title: String, authors: Vec<String>, keywords: Vec<String>) {
        let book = Book {
            title: title.clone(),
            authors: authors.clone(),
            keywords: keywords.clone(),
        };

        self.books.insert(isbn.clone(), book.clone());
        self.title_index.insert(title.clone(), isbn.clone());

        // Index authors
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }

        // Index keywords
        for keyword in keywords {
            self.keyword_index
                .entry(keyword)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }
    }

    fn find_by_isbn(&self, isbn: &str) -> Option<&Book> {
        self.books.get(isbn)
    }

    fn find_by_title(&self, title: &str) -> Option<&Book> {
        self.title_index.get(title).and_then(|isbn| self.books.get(isbn))
    }

    fn find_by_author(&self, author: &str) -> Vec<&Book> {
        self.author_index
            .get(author)
            .map_or(vec![], |isbns| {
                isbns
                    .iter()
                    .filter_map(|isbn| self.books.get(isbn))
                    .collect()
            })
    }
    fn find_by_keywords_intersection(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_intersection = keywords.iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .fold(None, |acc: Option<HashSet<String>>, set| {
                match acc {
                    Some(acc_set) => Some(acc_set.intersection(set).cloned().collect()),
                    None => Some(set.iter().cloned().collect()),
                }
            })
            .unwrap_or_default();

        self.get_books_by_isbns(isbns_intersection)
    }
    /*fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_union = self.collect_isbns_from_keywords(&keywords);
        self.get_books_by_isbns(&isbns_union)
    }*/
    /*fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_union = self.collect_isbns_from_keywords(&keywords);
        self.get_books_by_isbns(&isbns_union)
    }*/
    fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_union = self.collect_isbns_from_keywords(&keywords);
        self.get_books_by_isbns(isbns_union)
    }



    /*fn collect_isbns_from_keywords(&self, keywords: &[&str]) -> HashSet<&String> {
        keywords.iter().filter_map(|keyword| self.keyword_index.get(*keyword)).flatten().collect()
    }*/
    /*fn collect_isbns_from_keywords<'a>(&'a self, keywords: &[&str]) -> HashSet<&'a String> {
        keywords
            .iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .flat_map(|isbns| isbns.iter()) // Itera sobre os ISBNs e pega referências
            .collect() // Cria o HashSet de referências para String
    }*/
    fn collect_isbns_from_keywords(&self, keywords: &[&str]) -> HashSet<String> {
        keywords
            .iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .flat_map(|isbns| isbns.iter()) // Itera sobre os ISBNs (referências)
            .map(|isbn| isbn.to_string()) // Converte &String para String
            .collect() // Retorna HashSet<String>
    }



    /*fn get_books_by_isbns<'a>(&'a self, isbns: &HashSet<&'a String>) -> Vec<&'a Book> {
        isbns.iter()
            .filter_map(|isbn| self.books.get(*isbn))
            .collect()
    }*/
    /*fn get_books_by_isbns<'a>(&'a self, isbns: HashSet<String>) -> Vec<&'a Book> {
        isbns
            .iter()
            .filter_map(|isbn| self.books.get(*isbn))
            .collect()
    }*/
    fn get_books_by_isbns<'a>(&'a self, isbns: HashSet<String>) -> Vec<&'a Book> {
        isbns
            .iter()
            .filter_map(|isbn| self.books.get(isbn))
            .collect()
    }


}
fn main() {
    let mut library = Library::new();

    library.add_book(
        "978-0-123456-47-2".to_string(),
        "Rust Programming".to_string(),
        vec!["John Doe".to_string(), "Jane Smith".to_string()],
        vec!["Rust".to_string(), "Programming".to_string(), "Systems".to_string()],
    );

    library.add_book(
        "978-0-987654-32-1".to_string(),
        "Advanced Rust".to_string(),
        vec!["Jane Smith".to_string()],
        vec!["Rust".to_string(), "Advanced".to_string()],
    );

    println!("Find by ISBN:");
    if let Some(book) = library.find_by_isbn("978-0-123456-47-2") {
        println!("{:?}", book);
    }

    println!("\nFind by Title:");
    if let Some(book) = library.find_by_title("Advanced Rust") {
        println!("{:?}", book);
    }

    println!("\nFind by Author (Jane Smith):");
    for book in library.find_by_author("Jane Smith") {
        println!("{:?}", book);
    }

    println!("\nFind by Keywords (Intersection - Rust, Programming):");
    for book in library.find_by_keywords_intersection(vec!["Rust", "Programming"]) {
        println!("{:?}", book);
    }

    println!("\nFind by Keywords (Union - Rust, Advanced):");
    for book in library.find_by_keywords_union(vec!["Rust", "Advanced"]) {
        println!("{:?}", book);
    }
}

/*impl Library {
    fn new() -> Self {
        Library {
            books: HashMap::new(),
            title_index: HashMap::new(),
            author_index: HashMap::new(),
            keyword_index: HashMap::new(),
        }
}

    fn add_book(&mut self, isbn: String, title: String, authors: Vec<String>, keywords: Vec<String>) {
        let book = Book {
            title: title.clone(),
            authors: authors.clone(),
            keywords: keywords.clone(),
        };

        self.books.insert(isbn.clone(), book.clone());
        self.title_index.insert(title.clone(), isbn.clone());

        // Index authors
        for author in authors {
            self.author_index
                .entry(author)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }

        // Index keywords
        for keyword in keywords {
            self.keyword_index
                .entry(keyword)
                .or_insert_with(HashSet::new)
                .insert(isbn.clone());
        }
    }

    fn find_by_isbn(&self, isbn: &str) -> Option<&Book> {
        self.books.get(isbn)
    }

    fn find_by_title(&self, title: &str) -> Option<&Book> {
        self.title_index.get(title).and_then(|isbn| self.books.get(isbn))
    }

    fn find_by_author(&self, author: &str) -> Vec<&Book> {
        self.author_index
            .get(author)
            .map_or(vec![], |isbns| {
                isbns
                    .iter()
                    .filter_map(|isbn| self.books.get(isbn))
                    .collect()
            })
    }

    fn find_by_keywords_intersection(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let isbns_intersection = keywords.iter()
            .filter_map(|keyword| self.keyword_index.get(*keyword))
            .fold(None, |acc: Option<HashSet<&String>>, set| {
                match acc {
                    Some(acc_set) => Some(acc_set.intersection(&set.iter().collect::<HashSet<_>>()).cloned().collect()),
                    None => Some(set.iter().cloned().collect()),
                }
            })
            .unwrap_or_default();

        self.get_books_by_isbns(&isbns_intersection)
    }
    fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let mut union = HashSet::new();
        for keyword in keywords {
            if let Some(isbns) = self.keyword_index.get(keyword) {
                union.extend(isbns);
            }
        }

        union
            .iter()
            // Desreferencia explicitamente o `isbn` para evitar o problema de &&String
            .filter_map(|isbn| {
                self.books.get(&isbn)
            })
            .collect()
    }
   /* fn find_by_keywords_union(&self, keywords: Vec<&str>) -> Vec<&Book> {
        let mut union = HashSet::new();
        for keyword in keywords {
            if let Some(isbns) = self.keyword_index.get(keyword) {
                union.extend(isbns);
            }
        }

        union
            .iter()
            .filter_map(|isbn| self.books.get(&isbn))
            .collect()
    }*/
}*/