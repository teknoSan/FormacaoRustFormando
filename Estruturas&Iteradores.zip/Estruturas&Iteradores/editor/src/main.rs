use std::collections::HashMap;

#[derive(Debug, Copy, Clone)]
enum Operacao {
    Adicionar,
    Remover,
    UpperCase,
    LowerCase,
}

fn aplicar_operacao(mut texto: String, operacao: &Operacao, valor: Option<&str>) -> String {
    match operacao {
        Operacao::Adicionar => {
            if let Some(valor) = valor {
                texto.push_str(valor);
            }
            texto
        }
        Operacao::Remover => {
            if let Some(valor) = valor {
                texto = texto.replace(valor, "");
            }
            texto
        }
        Operacao::UpperCase => texto.to_uppercase(),
        Operacao::LowerCase => texto.to_lowercase(),
    }
}

fn editar_string(texto: String, operador: char, valor: Option<&str>) -> String {
    let operacao = match operador {
        '+' => Operacao::Adicionar,
        '-' => Operacao::Remover,
        'U' => Operacao::UpperCase,
        'L' => Operacao::LowerCase,
        _ => panic!("Operador inválido: {}", operador),
    };

    aplicar_operacao(texto, &operacao, valor)
}

fn main() {
    let mut texto = String::from("O Rust é incrível");

    println!("Texto original: {}", texto);

    // Adicionar texto
    texto = editar_string(texto, '+', Some("!!!"));
    println!("Após adicionar: {}", texto);

    // Transformar em maiúsculas (upper case)
    texto = editar_string(texto, 'U', None);
    println!("Após maiúsculas: {}", texto);

    // Transformar em minúsculas (lower case)
    texto = editar_string(texto, 'L', None);
    println!("Após minúsculas: {}", texto);

    // Remover texto
    texto = editar_string(texto, '-', Some("incrível"));
    println!("Após remoção: {}", texto);
}

#[cfg(test)]
mod string_edit_tests {
    use super::*;

    #[test]
    fn test_editar_string() {
        let texto = String::from("Hello, Rust!");

        // Testa adição
        let texto = editar_string(texto, '+', Some(" World"));
        assert_eq!(texto, "Hello, Rust! World");

        // Testa remoção
        let texto = editar_string(texto, '-', Some("Rust"));
        assert_eq!(texto, "Hello, ! World");

        // Testa upper case
        let texto = editar_string(texto, 'U', None);
        assert_eq!(texto, "HELLO, ! WORLD");

        // Testa lower case
        let texto = editar_string(texto, 'L', None);
        assert_eq!(texto, "hello, ! world");
    }
}
