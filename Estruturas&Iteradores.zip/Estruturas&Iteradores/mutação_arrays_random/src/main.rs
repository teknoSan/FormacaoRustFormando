fn main() {
    let mut array = vec![10, 20, 30, 40, 50];

    println!("Array original: {:?}", array);

    // Aplicar uma soma de 5 a cada elemento
    array = mut_array_iterator(array, '+', 5);
    println!("Após soma de 5: {:?}", array);

    // Aplicar uma subtração de 10 a cada elemento
    array = mut_array_iterator(array, '-', 10);
    println!("Após subtração de 10: {:?}", array);

    // Aplicar uma multiplicação por 2 a cada elemento
    array = mut_array_iterator(array, '*', 2);
    println!("Após multiplicação por 2: {:?}", array);

    // Aplicar uma divisão por 2 a cada elemento
    array = mut_array_iterator(array, '/', 2);
    println!("Após divisão por 2: {:?}", array);
}

#[derive(Debug, Copy, Clone)]
enum Operacao {
    Soma,
    Subtracao,
    Multiplicacao,
    Divisao,
}

fn aplicar_operacao(valor: u32, operacao: &Operacao, outro_valor: u32) -> u32 {
    match operacao {
        Operacao::Soma => valor + outro_valor,
        Operacao::Subtracao => valor - outro_valor,
        Operacao::Multiplicacao => valor * outro_valor,
        Operacao::Divisao => {
            if outro_valor != 0 {
                valor / outro_valor
            } else {
                valor // Se o divisor for 0, retorna o valor original
            }
        }
    }
}

fn mut_array_iterator(array: Vec<u32>, operador: char, outro_valor: u32) -> Vec<u32> {
    let operacao = match operador {
        '+' => Operacao::Soma,
        '-' => Operacao::Subtracao,
        '*' => Operacao::Multiplicacao,
        '/' => Operacao::Divisao,
        _ => panic!("Operador inválido: {}", operador),
    };

    array
        .into_iter()
        .map(|elemento| aplicar_operacao(elemento, &operacao, outro_valor))
        .collect()
}

#[cfg(test)]
mod mutable_array_test {
    const OWNERSHIP_TEST_ARRAY: [u32; 5] = [1, 2, 3, 4, 5];

    #[test]
    fn test_mut_ref_mutation() {
        let array = OWNERSHIP_TEST_ARRAY.to_vec();

        let array = super::mut_array_iterator(array, '+', 1);
        assert_eq!(array, [2, 3, 4, 5, 6]);

        let array = super::mut_array_iterator(array, '-', 1);
        assert_eq!(array, [1, 2, 3, 4, 5]);

        let array = super::mut_array_iterator(array, '*', 2);
        assert_eq!(array, [2, 4, 6, 8, 10]);

        let array = super::mut_array_iterator(array, '/', 2);
        assert_eq!(array, [1, 2, 3, 4, 5]);
    }
}