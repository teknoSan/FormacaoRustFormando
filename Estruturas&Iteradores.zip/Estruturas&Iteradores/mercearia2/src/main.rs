use std::collections::HashMap;

#[derive(Debug, Clone)]
struct Produto {
    id: u32,
    nome: String,
    data_validade: String,
    preco: f64,
    quantidade: u32,
}

#[derive(Debug, Clone, Eq, Hash, PartialEq)]
struct Localizacao {
    fileira: u32,
    prateleira: u32,
    zona: char,
}

#[derive(Debug)]
struct Mercearia {
    inventario: HashMap<Localizacao, Vec<Produto>>,
}

impl Mercearia {
    fn new() -> Self {
        Mercearia {
            inventario: HashMap::new(),
        }
    }

    fn adicionar_produto(&mut self, localizacao: Localizacao, produto: Produto) {
        if let Some(produtos) = self.inventario.get_mut(&localizacao) {
            if produtos.iter().any(|p| p.id == produto.id) {
                println!("Erro: Produto com ID {} já existe nesta localização!", produto.id);
                return;
            }
        }

        self.inventario
            .entry(localizacao)
            .or_insert_with(Vec::new)
            .push(produto);

        println!("Produto adicionado com sucesso!");
    }

    fn mover_produto(&mut self, origem: &Localizacao, destino: Localizacao, id_produto: u32) {
        let produto_transferido = if let Some(produtos) = self.inventario.get_mut(origem) {
            if let Some(index) = produtos.iter().position(|p| p.id == id_produto) {
                Some(produtos.remove(index))
            } else {
                println!("Produto não encontrado na localização de origem.");
                return;
            }
        } else {
            println!("Localização de origem não encontrada.");
            return;
        };

        if let Some(produto) = produto_transferido {
            self.adicionar_produto(destino, produto);

            if let Some(produtos) = self.inventario.get_mut(origem) {
                if produtos.is_empty() {
                    self.inventario.remove(origem);
                }
            }

            println!("Produto movido com sucesso!");
        }
    }

    fn listar_inventario(&self) {
        if self.inventario.is_empty() {
            println!("A mercearia está vazia!");
            return;
        }

        println!("Inventário da Mercearia:");
        for (local, produtos) in self.inventario.iter().filter(|(_, produtos)| !produtos.is_empty()) {
            println!(
                "Localização - Fileira: {}, Prateleira: {}, Zona: {}",
                local.fileira, local.prateleira, local.zona
            );
            for produto in produtos {
                println!(
                    "    ID: {}, Nome: {}, Validade: {}, Preço: {:.2}, Quantidade: {}",
                    produto.id, produto.nome, produto.data_validade, produto.preco, produto.quantidade
                );
            }
        }
    }
}

fn main() {
    let mut mercearia = Mercearia::new();

    let produto1 = Produto {
        id: 1,
        nome: "Maçã".to_string(),
        data_validade: "2026-01-01".to_string(),
        preco: 2.5,
        quantidade: 100,
    };

    let produto2 = Produto {
        id: 2,
        nome: "Banana".to_string(),
        data_validade: "2025-12-10".to_string(),
        preco: 1.5,
        quantidade: 120,
    };

    let local1 = Localizacao {
        fileira: 1,
        prateleira: 1,
        zona: 'A',
    };

    let local2 = Localizacao {
        fileira: 2,
        prateleira: 1,
        zona: 'B',
    };

    mercearia.adicionar_produto(local1.clone(), produto1);
    mercearia.adicionar_produto(local2.clone(), produto2);

    mercearia.listar_inventario();
    mercearia.mover_produto(&local2, local1.clone(), 2);
    mercearia.listar_inventario();
}
